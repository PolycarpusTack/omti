# utils.py
import logging
from typing import List, Optional

# Configure logging
logger = logging.getLogger(__name__)

def split_file_into_chunks(file_content: str, max_chunk_tokens: int = 5000, 
                           overlap_tokens: int = 100, 
                           preserve_paragraphs: bool = True) -> List[str]:
    """
    Split a file into chunks based on token count with configurable options.
    
    Args:
        file_content: The content of the file to split
        max_chunk_tokens: Maximum number of tokens (words) per chunk
        overlap_tokens: Number of tokens to overlap between chunks for context
        preserve_paragraphs: Try to avoid splitting in the middle of paragraphs
        
    Returns:
        List of string chunks from the file content
    """
    if not file_content:
        logger.warning("Empty file content provided for chunking")
        return []
    
    try:
        # Split into lines first
        lines = file_content.split('\n')
        chunks = []
        current_chunk = ""
        current_token_count = 0
        
        # Track empty lines as potential paragraph boundaries
        empty_line_indices = []
        
        for i, line in enumerate(lines):
            # Count tokens in this line (approximated by splitting on whitespace)
            line_tokens = line.split()
            line_token_count = len(line_tokens)
            
            # Track empty lines for paragraph preservation
            if preserve_paragraphs and not line.strip():
                empty_line_indices.append(i)
            
            # Check if adding this line would exceed the token limit
            if current_token_count + line_token_count <= max_chunk_tokens:
                # Add the line to the current chunk
                current_chunk += line + "\n"
                current_token_count += line_token_count
            else:
                # Current chunk is full
                if current_chunk.strip():
                    chunks.append(current_chunk)
                    
                    # Create overlap text from the end of the current chunk
                    current_tokens = current_chunk.split()
                    overlap_text = " ".join(current_tokens[-overlap_tokens:]) + "\n" if overlap_tokens > 0 else ""
                else:
                    overlap_text = ""
                
                # Start a new chunk with the overlap plus this line
                current_chunk = overlap_text + line + "\n"
                current_token_count = len(current_chunk.split())
                
        # Add the last chunk if it has content
        if current_chunk.strip():
            chunks.append(current_chunk)
        
        # Log chunking results
        logger.info(f"Split content into {len(chunks)} chunks (max {max_chunk_tokens} tokens per chunk)")
        
        return chunks
        
    except Exception as e:
        logger.error(f"Error splitting file into chunks: {str(e)}")
        # Fall back to original simple implementation if there's an error
        return _simple_split_into_chunks(file_content, max_chunk_tokens)

def _simple_split_into_chunks(file_content: str, max_chunk_tokens: int = 5000) -> List[str]:
    """
    Fallback simple implementation of chunk splitting.
    """
    lines = file_content.split('\n')
    chunks = []
    current_chunk = ""

    for line in lines:
        if len(current_chunk.split()) + len(line.split()) < max_chunk_tokens:
            current_chunk += line + "\n"
        else:
            chunks.append(current_chunk)
            current_chunk = line + "\n"

    if current_chunk.strip():
        chunks.append(current_chunk)
    return chunks

def estimate_token_count(text: str) -> int:
    """
    Estimate the number of tokens in a text.
    This is a simple approximation - for production use consider using 
    a proper tokenizer from a library like tiktoken or transformers.
    
    Args:
        text: The text to count tokens in
        
    Returns:
        Estimated token count
    """
    # Simple approximation: split on whitespace and count
    return len(text.split())