// backend/database/migrations/20250415-initial-schema.js
'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    // Create users table
    await queryInterface.createTable('users', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      username: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
      },
      email: {
        type: Sequelize.STRING,
        allowNull: false,
        unique: true
      },
      password: {
        type: Sequelize.STRING,
        allowNull: false
      },
      preferences: {
        type: Sequelize.JSONB,
        allowNull: true,
        defaultValue: {}
      },
      lastLogin: {
        type: Sequelize.DATE,
        allowNull: true
      },
      isActive: {
        type: Sequelize.BOOLEAN,
        defaultValue: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Create analyses table
    await queryInterface.createTable('analyses', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      userId: {
        type: Sequelize.UUID,
        allowNull: true,
        references: {
          model: 'users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'SET NULL'
      },
      fileName: {
        type: Sequelize.STRING,
        allowNull: false
      },
      fileSize: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      fileType: {
        type: Sequelize.STRING,
        allowNull: false
      },
      modelId: {
        type: Sequelize.STRING,
        allowNull: false
      },
      modelProvider: {
        type: Sequelize.STRING,
        allowNull: false
      },
      analysisType: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'original'
      },
      language: {
        type: Sequelize.STRING,
        allowNull: false,
        defaultValue: 'en'
      },
      processingTime: {
        type: Sequelize.FLOAT,
        allowNull: true
      },
      status: {
        type: Sequelize.ENUM('pending', 'processing', 'completed', 'failed'),
        defaultValue: 'pending'
      },
      chunks: {
        type: Sequelize.INTEGER,
        allowNull: true
      },
      severity: {
        type: Sequelize.ENUM('critical', 'high', 'medium', 'low', 'unknown'),
        defaultValue: 'unknown'
      },
      rootCauses: {
        type: Sequelize.ARRAY(Sequelize.STRING),
        defaultValue: []
      },
      shareUrl: {
        type: Sequelize.STRING,
        allowNull: true,
        unique: true
      },
      metadata: {
        type: Sequelize.JSONB,
        allowNull: true,
        defaultValue: {}
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Create analysis_results table
    await queryInterface.createTable('analysis_results', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      analysisId: {
        type: Sequelize.UUID,
        allowNull: false,
        references: {
          model: 'analyses',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      chunk: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      totalChunks: {
        type: Sequelize.INTEGER,
        allowNull: false
      },
      technicalAnalysis: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      simplifiedAnalysis: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      suggestedSolutions: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      errorMessage: {
        type: Sequelize.TEXT,
        allowNull: true
      },
      processingTime: {
        type: Sequelize.FLOAT,
        allowNull: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Create tags table
    await queryInterface.createTable('tags', {
      id: {
        type: Sequelize.UUID,
        defaultValue: Sequelize.UUIDV4,
        primaryKey: true
      },
      name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      color: {
        type: Sequelize.STRING,
        allowNull: true,
        defaultValue: '#3b82f6'
      },
      userId: {
        type: Sequelize.UUID,
        allowNull: true,
        references: {
          model: 'users',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE'
      },
      isGlobal: {
        type: Sequelize.BOOLEAN,
        defaultValue: false
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Create analysis_tags junction table
    await queryInterface.createTable('analysis_tags', {
      analysisId: {
        type: Sequelize.UUID,
        references: {
          model: 'analyses',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
        primaryKey: true
      },
      tagId: {
        type: Sequelize.UUID,
        references: {
          model: 'tags',
          key: 'id'
        },
        onUpdate: 'CASCADE',
        onDelete: 'CASCADE',
        primaryKey: true
      },
      createdAt: {
        type: Sequelize.DATE,
        allowNull: false
      },
      updatedAt: {
        type: Sequelize.DATE,
        allowNull: false
      }
    });

    // Add indexes
    await queryInterface.addIndex('analyses', ['userId']);
    await queryInterface.addIndex('analyses', ['createdAt']);
    await queryInterface.addIndex('analyses', ['status']);
    await queryInterface.addIndex('analyses', ['severity']);
    await queryInterface.addIndex('analysis_results', ['analysisId']);
    await queryInterface.addIndex('tags', ['userId']);
    await queryInterface.addIndex('tags', ['isGlobal']);
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('analysis_tags');
    await queryInterface.dropTable('tags');
    await queryInterface.dropTable('analysis_results');
    await queryInterface.dropTable('analyses');
    await queryInterface.dropTable('users');
  }
};
