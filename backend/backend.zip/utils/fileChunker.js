// backend/utils/fileChunker.js

/**
 * Utility for chunking large files for LLM processing
 */
class FileChunker {
    /**
     * Split a file into chunks based on token size estimation
     * @param {string} content - File content
     * @param {number} maxTokensPerChunk - Maximum tokens per chunk
     * @returns {Array} Array of chunks
     */
    splitIntoChunks(content, maxTokensPerChunk = 4000) {
      // Estimate: 1 token ~= 4 characters for English text
      const charsPerToken = 4;
      const maxCharsPerChunk = maxTokensPerChunk * charsPerToken;
      
      // Reserve some tokens for the prompt instructions and response
      const reservedChars = 1000 * charsPerToken;
      const effectiveMaxChars = maxCharsPerChunk - reservedChars;
      
      // Split by lines first
      const lines = content.split('\n');
      const chunks = [];
      let currentChunk = '';
      
      for (const line of lines) {
        // If adding this line would exceed the chunk size, start a new chunk
        if (currentChunk.length + line.length > effectiveMaxChars && currentChunk.length > 0) {
          chunks.push(currentChunk);
          currentChunk = '';
        }
        
        // Add the line to the current chunk
        if (currentChunk.length > 0) {
          currentChunk += '\n';
        }
        currentChunk += line;
        
        // Special case for very long lines
        if (line.length > effectiveMaxChars) {
          chunks.push(currentChunk);
          currentChunk = '';
        }
      }
      
      // Add the last chunk if it has content
      if (currentChunk.length > 0) {
        chunks.push(currentChunk);
      }
      
      return chunks;
    }
    
    /**
     * Estimate the number of tokens in a text
     * @param {string} text - Input text
     * @returns {number} Estimated token count
     */
    estimateTokenCount(text) {
      // Very simple estimation: 1 token ~= 4 characters for English text
      return Math.ceil(text.length / 4);
    }
    
    /**
     * Split a file by context while trying to maintain logical boundaries
     * @param {string} content - File content
     * @param {number} maxTokensPerChunk - Maximum tokens per chunk
     * @returns {Array} Array of chunks
     */
    splitByContext(content, maxTokensPerChunk = 4000) {
      // This is a more sophisticated chunking method that tries to maintain logical boundaries
      
      // Estimate: 1 token ~= 4 characters for English text
      const charsPerToken = 4;
      const maxCharsPerChunk = maxTokensPerChunk * charsPerToken;
      
      // Reserve some tokens for the prompt instructions and response
      const reservedChars = 1000 * charsPerToken;
      const effectiveMaxChars = maxCharsPerChunk - reservedChars;
      
      // Look for logical boundary markers
      const boundaryMarkers = [
        // Log section headers
        /^={5,}$/m,
        /^-{5,}$/m,
        /^#{5,}$/m,
        // Timestamp patterns
        /^\[\d{4}-\d{2}-\d{2}/m,
        /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/m,
        // Log level indicators
        /^(ERROR|WARN|INFO|DEBUG):/m,
        // Stack trace start
        /^Exception in thread/m,
        /^Caused by:/m,
        /^at /m,
        // Process indicators
        /^Process ID:/m,
        // Thread indicators
        /^Thread \d+:/m
      ];
      
      // Split by detected boundaries
      let chunks = [content];
      for (const marker of boundaryMarkers) {
        const newChunks = [];
        
        for (const chunk of chunks) {
          if (chunk.length <= effectiveMaxChars) {
            newChunks.push(chunk);
            continue;
          }
          
          // Split by marker
          const parts = chunk.split(marker);
          if (parts.length === 1) {
            // No marker found in this chunk
            newChunks.push(chunk);
            continue;
          }
          
          let currentPart = '';
          for (let i = 0; i < parts.length; i++) {
            const part = parts[i];
            const delimiter = i > 0 ? marker.toString().replace(/^\/|\/[gmi]*$/g, '') : '';
            
            if (currentPart.length + delimiter.length + part.length > effectiveMaxChars && currentPart.length > 0) {
              newChunks.push(currentPart);
              currentPart = delimiter + part;
            } else {
              currentPart += delimiter + part;
            }
          }
          
          if (currentPart.length > 0) {
            newChunks.push(currentPart);
          }
        }
        
        chunks = newChunks;
      }
      
      // Final pass to ensure no chunk exceeds the limit
      const finalChunks = [];
      for (const chunk of chunks) {
        if (chunk.length <= effectiveMaxChars) {
          finalChunks.push(chunk);
        } else {
          // Fall back to simple chunking for oversized chunks
          const simpleChunks = this.splitIntoChunks(chunk, maxTokensPerChunk);
          finalChunks.push(...simpleChunks);
        }
      }
      
      return finalChunks;
    }
  }
  
  module.exports = new FileChunker();