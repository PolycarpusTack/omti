// backend/controllers/llmController.js

const axios = require('axios');
const { OpenAI } = require('openai');

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

// Initialize Ollama API endpoints
const OLLAMA_API = process.env.OLLAMA_API_URL || 'http://localhost:11434/api';

/**
 * Controller for handling LLM-related operations
 */
class LLMController {
  /**
   * Get list of available models
   */
  async getModels(req, res) {
    try {
      const models = [];
      
      // Try to get Ollama models
      try {
        const ollamaResponse = await axios.get(`${OLLAMA_API}/tags`);
        if (ollamaResponse.data && ollamaResponse.data.models) {
          const ollamaModels = ollamaResponse.data.models.map(model => ({
            id: model.name,
            name: model.name,
            provider: 'ollama',
            loaded: true,
            status: 'healthy'
          }));
          models.push(...ollamaModels);
        }
      } catch (ollamaError) {
        console.warn('Failed to fetch Ollama models:', ollamaError.message);
      }
      
      // Try to get OpenAI models if an API key is configured
      if (process.env.OPENAI_API_KEY) {
        try {
          const openaiResponse = await openai.models.list();
          const openaiModels = openaiResponse.data.filter(model => 
            model.id.includes('gpt')
          ).map(model => ({
            id: model.id,
            name: model.id.startsWith('gpt-4') ? 'GPT-4' : 'GPT-3.5',
            provider: 'openai',
            loaded: true,
            status: 'healthy'
          }));
          models.push(...openaiModels);
        } catch (openaiError) {
          console.warn('Failed to fetch OpenAI models:', openaiError.message);
        }
      }
      
      res.json({ models });
    } catch (error) {
      console.error('Error fetching models:', error);
      res.status(500).json({ error: 'Failed to fetch models' });
    }
  }
  
  /**
   * Get model status and metrics
   */
  async getModelStatus(req, res) {
    try {
      const modelStatus = [];
      
      // Get Ollama model stats
      try {
        const ollamaStatusRes = await axios.get(`${OLLAMA_API}/tags`);
        if (ollamaStatusRes.data && ollamaStatusRes.data.models) {
          const ollamaModels = ollamaStatusRes.data.models.map(model => {
            // For a real implementation, you might run a quick benchmark
            // Here we'll use dummy values
            return {
              name: model.name,
              provider: 'ollama',
              status: 'healthy',
              health: 'healthy',
              avg_response_time: 1.5,
              throughput: 30.0
            };
          });
          modelStatus.push(...ollamaModels);
        }
      } catch (ollamaError) {
        console.warn('Failed to fetch Ollama model status:', ollamaError.message);
      }
      
      // Add OpenAI model status
      if (process.env.OPENAI_API_KEY) {
        modelStatus.push(
          {
            name: 'gpt-4',
            provider: 'openai',
            status: 'healthy',
            health: 'healthy',
            avg_response_time: 2.8,
            throughput: 45.2
          },
          {
            name: 'gpt-3.5-turbo',
            provider: 'openai',
            status: 'healthy',
            health: 'healthy',
            avg_response_time: 1.1,
            throughput: 65.5
          }
        );
      }
      
      res.json({ models: modelStatus });
    } catch (error) {
      console.error('Error fetching model status:', error);
      res.status(500).json({ error: 'Failed to fetch model status' });
    }
  }
  
  /**
   * Run a quick benchmark on a specified model
   */
  async benchmarkModel(req, res) {
    const { modelId } = req.params;
    
    try {
      let benchmarkResult = null;
      
      if (modelId.includes('gpt')) {
        // OpenAI benchmark
        benchmarkResult = await this._benchmarkOpenAI(modelId);
      } else {
        // Ollama benchmark
        benchmarkResult = await this._benchmarkOllama(modelId);
      }
      
      res.json(benchmarkResult);
    } catch (error) {
      console.error(`Error benchmarking model ${modelId}:`, error);
      res.status(500).json({ error: `Failed to benchmark model: ${error.message}` });
    }
  }
  
  /**
   * Process a request through the selected LLM
   */
  async processWithLLM(req, res) {
    const { 
      modelId, 
      prompt, 
      temperature, 
      topP, 
      maxTokens,
      frequencyPenalty,
      presencePenalty 
    } = req.body;
    
    try {
      let response;
      
      if (modelId.includes('gpt')) {
        // Use OpenAI API
        response = await this._processWithOpenAI(
          modelId,
          prompt,
          temperature,
          topP,
          maxTokens,
          frequencyPenalty,
          presencePenalty
        );
      } else {
        // Use Ollama API
        response = await this._processWithOllama(
          modelId,
          prompt,
          temperature,
          topP,
          maxTokens
        );
      }
      
      res.json(response);
    } catch (error) {
      console.error('Error processing with LLM:', error);
      res.status(500).json({ error: `Failed to process with LLM: ${error.message}` });
    }
  }
  
  /**
   * Private method for benchmarking an OpenAI model
   */
  async _benchmarkOpenAI(modelId) {
    const startTime = Date.now();
    
    // Use a standard test prompt
    const testPrompt = 'Explain the concept of quantum computing in 3 sentences.';
    
    const response = await openai.chat.completions.create({
      model: modelId,
      messages: [{ role: 'user', content: testPrompt }],
      max_tokens: 100
    });
    
    const endTime = Date.now();
    const inferenceTime = (endTime - startTime) / 1000;
    const outputTokens = response.usage.completion_tokens;
    const tokensPerSecond = Math.round(outputTokens / inferenceTime);
    
    return {
      inferenceTime: inferenceTime.toFixed(2),
      tokensPerSecond,
      inputTokens: response.usage.prompt_tokens,
      outputTokens,
      totalTokens: response.usage.total_tokens,
      // OpenAI doesn't provide memory usage info
      memoryUsage: 'N/A'
    };
  }
  
  /**
   * Private method for benchmarking an Ollama model
   */
  async _benchmarkOllama(modelId) {
    const startTime = Date.now();
    
    // Use a standard test prompt
    const testPrompt = 'Explain the concept of quantum computing in 3 sentences.';
    
    const response = await axios.post(`${OLLAMA_API}/generate`, {
      model: modelId,
      prompt: testPrompt,
      options: {
        num_predict: 100
      }
    });
    
    const endTime = Date.now();
    const inferenceTime = (endTime - startTime) / 1000;
    
    // Ollama doesn't provide direct token counts, so we'll estimate
    const outputText = response.data.response;
    const estimatedTokens = Math.round(outputText.split(/\s+/).length * 1.3);
    const tokensPerSecond = Math.round(estimatedTokens / inferenceTime);
    
    return {
      inferenceTime: inferenceTime.toFixed(2),
      tokensPerSecond,
      // Ollama provides eval count which is similar to tokens
      inputTokens: response.data.eval_count,
      outputTokens: estimatedTokens,
      totalTokens: response.data.eval_count + estimatedTokens,
      // Ollama may provide this in future versions
      memoryUsage: 'N/A'
    };
  }
  
  /**
   * Private method for processing with OpenAI
   */
  async _processWithOpenAI(
    modelId,
    prompt,
    temperature = 0.7,
    topP = 0.9,
    maxTokens = 2000,
    frequencyPenalty = 0,
    presencePenalty = 0
  ) {
    const response = await openai.chat.completions.create({
      model: modelId,
      messages: [{ role: 'user', content: prompt }],
      temperature,
      top_p: topP,
      max_tokens: maxTokens,
      frequency_penalty: frequencyPenalty,
      presence_penalty: presencePenalty
    });
    
    return {
      text: response.choices[0].message.content,
      usage: response.usage
    };
  }
  
  /**
   * Private method for processing with Ollama
   */
  async _processWithOllama(
    modelId,
    prompt,
    temperature = 0.7,
    topP = 0.9,
    maxTokens = 2000
  ) {
    const response = await axios.post(`${OLLAMA_API}/generate`, {
      model: modelId,
      prompt: prompt,
      options: {
        temperature,
        top_p: topP,
        num_predict: maxTokens
      }
    });
    
    return {
      text: response.data.response,
      usage: {
        prompt_tokens: response.data.prompt_eval_count,
        completion_tokens: response.data.eval_count,
        total_tokens: response.data.prompt_eval_count + response.data.eval_count
      }
    };
  }
}

module.exports = new LLMController();