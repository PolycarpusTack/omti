import React from 'react';
import { Tooltip } from 'react-tooltip';
import FileUploader from './FileUploader';
import StreamModeToggle from './StreamModeToggle';
import LLMSelector from '../../components/LLMSelector';

const AnalysisForm = ({
  // File handling props
  selectedFile,
  filePreview,
  dragActive,
  fileInputRef,
  handleDrag,
  handleDrop,
  handleFileSelect,
  clearSelectedFile,
  
  // Analysis configuration
  streamMode,
  onStreamModeChange,
  analysisType,
  
  // Model selection
  selectedModel,
  onModelSelect,
  
  // Action handlers
  onAnalyze,
  onDownload,
  onShare,
  showPatternInsights,
  onShowPatternInsights,
  patternInsightsCount,
  
  // State flags
  loading,
  analyses,
  showExportOptions,
  toggleExportOptions,
  setExportFormat,
}) => {
  return (
    <div>
      {/* LLM Selector */}
      <LLMSelector 
        selectedModel={selectedModel}
        onModelSelect={onModelSelect}
        disabled={loading}
      />
      
      {/* Main form container */}
      <div className="bg-white dark:bg-gray-700 rounded-lg p-4 mb-4 shadow-sm mt-4">
        <div className="mb-4">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-lg font-semibold dark:text-gray-200">Analysis Configuration</h2>
            <StreamModeToggle 
              streamMode={streamMode}
              onChange={onStreamModeChange}
              disabled={loading || analysisType === 'crash'}
            />
          </div>
          
          {/* File upload area */}
          <FileUploader
            selectedFile={selectedFile}
            filePreview={filePreview}
            dragActive={dragActive}
            fileInputRef={fileInputRef}
            handleDrag={handleDrag}
            handleDrop={handleDrop}
            handleFileSelect={handleFileSelect}
            clearSelectedFile={clearSelectedFile}
            loading={loading}
          />
        </div>
        
        {/* Action buttons */}
        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            <button
              onClick={onAnalyze}
              className={`px-4 py-2 bg-green-500 hover:bg-green-600 text-white rounded transition-transform hover:scale-105 ${(!selectedFile || loading) ? 'opacity-50 cursor-not-allowed' : ''}`}
              disabled={!selectedFile || loading}
              data-tooltip-id="analyze-tooltip"
              data-tooltip-content="Begin analysis of the selected file"
            >
              {loading ? 'Analyzing...' : 'Analyze'}
            </button>
            <Tooltip id="analyze-tooltip" place="top" />
            
            {analyses.length > 0 && !loading && (
              <>
                <div className="relative dropdown-container">
                  <button
                    onClick={toggleExportOptions}
                    className="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded transition-transform hover:scale-105 flex items-center"
                    data-tooltip-id="download-tooltip"
                    data-tooltip-content="Download analysis results"
                  >
                    <span>Download</span>
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                  </button>
                  <Tooltip id="download-tooltip" place="top" />
                  
                  {/* Export format dropdown */}
                  {showExportOptions && (
                    <div className="absolute top-full left-0 mt-1 w-36 bg-white dark:bg-gray-700 shadow-lg rounded-md overflow-hidden z-10">
                      <button 
                        className="w-full px-4 py-2 text-left text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600"
                        onClick={() => {
                          setExportFormat('txt');
                          toggleExportOptions();
                          onDownload('txt');
                        }}
                      >
                        Text (.txt)
                      </button>
                      <button 
                        className="w-full px-4 py-2 text-left text-gray-800 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-600"
                        onClick={() => {
                          setExportFormat('json');
                          toggleExportOptions();
                          onDownload('json');
                        }}
                      >
                        JSON (.json)
                      </button>
                    </div>
                  )}
                </div>
                
                <button
                  onClick={onShare}
                  className="px-4 py-2 bg-purple-500 hover:bg-purple-600 text-white rounded transition-transform hover:scale-105"
                  data-tooltip-id="share-tooltip"
                  data-tooltip-content="Generate a shareable link"
                >
                  Share
                </button>
                <Tooltip id="share-tooltip" place="top" />
              </>
            )}
          </div>
          
          {patternInsightsCount > 0 && (
            <button
              onClick={onShowPatternInsights}
              className="flex items-center text-amber-500 hover:text-amber-600"
              data-tooltip-id="insights-tooltip"
              data-tooltip-content="View detected patterns across analyses"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
              </svg>
              <span>Pattern Insights ({patternInsightsCount})</span>
            </button>
          )}
          <Tooltip id="insights-tooltip" place="left" />
        </div>
      </div>
    </div>
  );
};

export default AnalysisForm;