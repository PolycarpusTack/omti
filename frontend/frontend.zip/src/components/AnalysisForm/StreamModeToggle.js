import React from 'react';

const StreamModeToggle = ({ streamMode, onChange, disabled }) => {
  return (
    <div className="flex items-center space-x-2">
      <label className="inline-flex items-center text-sm">
        <input
          type="checkbox"
          className="form-checkbox h-4 w-4 text-blue-600"
          checked={streamMode}
          onChange={() => onChange(!streamMode)}
          disabled={disabled}
        />
        <span className="ml-2 text-gray-700 dark:text-gray-300">Streaming mode</span>
      </label>
    </div>
  );
};

export default StreamModeToggle;