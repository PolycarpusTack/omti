import React from 'react';
import { Tooltip } from 'react-tooltip';

const FileUploader = ({ 
  selectedFile,
  filePreview,
  dragActive,
  fileInputRef,
  handleDrag,
  handleDrop,
  handleFileSelect,
  clearSelectedFile,
  loading
}) => {
  return (
    <div className="mb-4">
      {selectedFile ? (
        <div className="border rounded p-3 bg-gray-50 dark:bg-gray-800">
          <div className="flex justify-between">
            <div>
              <p className="font-medium dark:text-gray-200">{selectedFile.name}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {(selectedFile.size / 1024).toFixed(2)} KB • {selectedFile.type || 'Unknown type'}
              </p>
            </div>
            <button 
              onClick={clearSelectedFile}
              className="text-red-500 hover:text-red-700"
              disabled={loading}
              data-tooltip-id="clear-file-tooltip"
              data-tooltip-content="Remove selected file"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
            <Tooltip id="clear-file-tooltip" place="left" />
          </div>
          {filePreview && (
            <div className="mt-2">
              <p className="text-xs text-gray-500 dark:text-gray-400 mb-1">Preview:</p>
              <pre className="text-xs bg-gray-100 dark:bg-gray-900 p-2 rounded overflow-auto max-h-20 dark:text-gray-300">{filePreview}</pre>
            </div>
          )}
        </div>
      ) : (
        <div 
          className={`border-2 border-dashed ${dragActive ? 'border-blue-400 bg-blue-50 dark:bg-blue-900/20' : 'border-gray-300 dark:border-gray-600'} rounded-lg p-6 text-center transition-colors duration-200`}
          onDragEnter={handleDrag}
          onDragOver={handleDrag}
          onDragLeave={handleDrag}
          onDrop={handleDrop}
        >
          <label htmlFor="file-upload" className="cursor-pointer">
            <svg xmlns="http://www.w3.org/2000/svg" className={`mx-auto h-12 w-12 ${dragActive ? 'text-blue-500' : 'text-gray-400'} transition-colors duration-200`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
            </svg>
            <p className={`mt-1 text-sm ${dragActive ? 'text-blue-500 font-medium' : 'text-gray-500 dark:text-gray-400'} transition-colors duration-200`}>
              {dragActive ? 'Drop file to upload' : 'Click to select or drag a file here'}
            </p>
          </label>
          <input
            ref={fileInputRef}
            id="file-upload"
            type="file"
            onChange={handleFileSelect}
            className="hidden"
            disabled={loading}
          />
        </div>
      )}
    </div>
  );
};

export default FileUploader;