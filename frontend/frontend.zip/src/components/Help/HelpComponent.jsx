import React, { useState } from 'react';

const HelpComponent = () => {
  const [activeSection, setActiveSection] = useState('overview');
  const [expandedItems, setExpandedItems] = useState({});

  const toggleSection = (section) => {
    setActiveSection(section === activeSection ? null : section);
  };

  const toggleItem = (itemId) => {
    setExpandedItems(prev => ({
      ...prev,
      [itemId]: !prev[itemId]
    }));
  };

  const Section = ({ id, title, children }) => (
    <div className={`mb-6 p-4 rounded-lg ${activeSection === id ? 'bg-blue-50 dark:bg-gray-700' : 'bg-white dark:bg-gray-800'}`}>
      <h2 
        className="text-xl font-bold mb-2 cursor-pointer flex items-center justify-between dark:text-white"
        onClick={() => toggleSection(id)}
      >
        {title}
        <span className="text-sm text-blue-500">
          {activeSection === id ? '▼' : '▶'}
        </span>
      </h2>
      {activeSection === id && (
        <div className="pl-2 dark:text-gray-200">
          {children}
        </div>
      )}
    </div>
  );

  const SubItem = ({ id, title, children }) => (
    <div className="mb-3">
      <h3 
        className="text-md font-semibold cursor-pointer flex items-center justify-between dark:text-gray-200"
        onClick={() => toggleItem(id)}
      >
        {title}
        <span className="text-xs text-blue-500">
          {expandedItems[id] ? '▼' : '▶'}
        </span>
      </h3>
      {expandedItems[id] && (
        <div className="pl-4 mt-1 text-sm dark:text-gray-300">
          {children}
        </div>
      )}
    </div>
  );

  return (
    <div className="max-w-4xl mx-auto bg-white dark:bg-gray-800 p-6 rounded-xl shadow-lg">
      <h1 className="text-3xl font-bold mb-6 text-center dark:text-white">One More Thing Insights - Help Guide</h1>
      
      <p className="mb-6 dark:text-gray-200">
        Welcome to the comprehensive help guide for One More Thing Insights. This document provides detailed information about all features and functionality of the application.
      </p>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <button 
          className="p-2 bg-blue-500 text-white rounded hover:bg-blue-600"
          onClick={() => {
            const sections = ['overview', 'file-upload', 'analysis-settings', 'models', 'results', 'filtering', 'export', 'history', 'patterns', 'analytics-dashboard', 'troubleshooting', 'settings', 'accessibility'];
            const expanded = {};
            sections.forEach(section => {
              expanded[section] = true;
            });
            setExpandedItems(expanded);
          }}
        >
          Expand All Sections
        </button>
        <button 
          className="p-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400 dark:bg-gray-600 dark:text-white dark:hover:bg-gray-500"
          onClick={() => setExpandedItems({})}
        >
          Collapse All Sections
        </button>
      </div>

      <div className="space-y-4">
        <Section id="overview" title="1. Application Overview">
          <p className="mb-3">
            One More Thing Insights is an advanced code and log analysis tool that leverages AI models to help identify issues, patterns, and insights in your code or log files. The application combines powerful AI analysis with user-friendly features to make debugging and troubleshooting more efficient.
          </p>
          
          <SubItem id="core-features" title="Core Features">
            <ul className="list-disc pl-5 space-y-1">
              <li>AI-powered code and log analysis</li>
              <li>Multiple analysis modes and model options</li>
              <li>Pattern detection across multiple analyses</li>
              <li>Detailed issue categorization and filtering</li>
              <li>Advanced analytics dashboard with visualizations</li>
              <li>Troubleshooting wizard with guided steps</li>
              <li>Shareable analysis results</li>
              <li>Analysis history management</li>
              <li>Dark/light theme support</li>
            </ul>
          </SubItem>
          
          <SubItem id="workflow" title="Typical Workflow">
            <ol className="list-decimal pl-5 space-y-1">
              <li>Upload a file (code or log) for analysis</li>
              <li>Configure analysis settings (model, language, type)</li>
              <li>Run the analysis</li>
              <li>Review the analytics dashboard for high-level insights</li>
              <li>Examine categorized issues and detailed analysis</li>
              <li>Use filters to focus on specific issues</li>
              <li>Use the troubleshooting wizard for guided resolution</li>
              <li>Export or share results as needed</li>
            </ol>
          </SubItem>
        </Section>

        <Section id="file-upload" title="2. File Upload & Handling">
          <p className="mb-3">
            The application supports multiple methods for uploading files for analysis.
          </p>
          
          <SubItem id="upload-methods" title="Upload Methods">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Drag and Drop:</strong> Drag files directly into the upload area</li>
              <li><strong>File Browser:</strong> Click the upload area to open a file browser</li>
              <li><strong>Clipboard Paste:</strong> Paste content from clipboard (for text files)</li>
            </ul>
          </SubItem>
          
          <SubItem id="supported-files" title="Supported File Types">
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Code Files:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>JavaScript (.js, .jsx, .ts, .tsx)</li>
                  <li>Python (.py)</li>
                  <li>Java (.java)</li>
                  <li>C/C++ (.c, .cpp, .h)</li>
                  <li>Go (.go)</li>
                  <li>Ruby (.rb)</li>
                  <li>PHP (.php)</li>
                  <li>Other common programming languages</li>
                </ul>
              </li>
              <li>
                <strong>Log Files:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>Text logs (.log, .txt)</li>
                  <li>JSON logs (.json)</li>
                  <li>XML logs (.xml)</li>
                  <li>CSV logs (.csv)</li>
                </ul>
              </li>
              <li>
                <strong>Configuration Files:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>JSON (.json)</li>
                  <li>YAML (.yml, .yaml)</li>
                  <li>TOML (.toml)</li>
                  <li>INI (.ini)</li>
                </ul>
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="file-preview" title="File Preview">
            <p>
              Once uploaded, the application provides a preview of the file content. For large files, this preview is limited to the first few kilobytes. The preview helps confirm you've selected the correct file before analysis.
            </p>
          </SubItem>
          
          <SubItem id="file-limits" title="File Size Limits">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Default Limit:</strong> 10MB per file</li>
              <li><strong>Extended Limit (with chunking):</strong> Up to 50MB with automatic chunking</li>
              <li><strong>Note:</strong> Very large files are automatically split into smaller chunks for analysis, which may impact the cohesiveness of results</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="analysis-settings" title="3. Analysis Configuration">
          <p className="mb-3">
            Before running an analysis, you can configure various settings to customize the process to your specific needs.
          </p>
          
          <SubItem id="analysis-types" title="Analysis Types">
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Original:</strong> Standard analysis that provides a comprehensive evaluation of the code or log file, including both technical insights and simplified explanation.
              </li>
              <li>
                <strong>Technical:</strong> Focuses on detailed technical analysis with specialized terminology, ideal for experienced developers.
              </li>
              <li>
                <strong>Simplified:</strong> Provides explanations in simpler terms with less technical jargon, suitable for non-technical stakeholders.
              </li>
              <li>
                <strong>Security-focused:</strong> Emphasizes security vulnerabilities and potential exploits in the code.
              </li>
              <li>
                <strong>Performance:</strong> Concentrates on identifying performance bottlenecks and optimization opportunities.
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="language-selection" title="Language Selection">
            <p>
              Specify the programming language or log format of your file for more accurate analysis. The application supports auto-detection but manual selection often yields better results, especially for:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Domain-specific languages</li>
              <li>Less common file formats</li>
              <li>Mixed content files</li>
              <li>Framework-specific code</li>
            </ul>
          </SubItem>
          
          <SubItem id="stream-mode" title="Stream Mode">
            <p>
              Stream mode controls how analysis results are delivered:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>Enabled:</strong> Results appear progressively as they're generated, allowing you to start reviewing before the entire analysis completes</li>
              <li><strong>Disabled:</strong> Results are delivered only after the entire analysis is complete, which may provide more coherent overall insights</li>
            </ul>
          </SubItem>
          
          <SubItem id="advanced-settings" title="Advanced Settings">
            <p>
              Advanced settings can be configured in the Settings modal:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>Max Tokens Per Chunk:</strong> Controls how text is split for analysis (default: 4000)</li>
              <li><strong>Analysis Timeout:</strong> Maximum time allowed for analysis before timing out (default: 60 seconds)</li>
              <li><strong>Context Window:</strong> How much surrounding context to include when analyzing specific sections</li>
              <li><strong>Chunk Overlap:</strong> Controls how much overlap between chunks when splitting large files</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="models" title="4. AI Model Selection">
          <p className="mb-3">
            The application supports multiple AI model providers and configurations for analysis.
          </p>
          
          <SubItem id="supported-models" title="Supported Model Providers">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>OpenAI Models:</strong> GPT-4, GPT-3.5 Turbo</li>
              <li><strong>Anthropic Models:</strong> Claude 2, Claude Instant</li>
              <li><strong>Ollama:</strong> For running local open-source models</li>
              <li><strong>Custom API:</strong> Support for custom AI endpoints</li>
            </ul>
          </SubItem>
          
          <SubItem id="model-settings" title="Model Settings">
            <p>
              Each model can be configured with different parameters:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>Temperature:</strong> Controls randomness/creativity (0.0-1.0)</li>
              <li><strong>Top P:</strong> Controls diversity of model outputs</li>
              <li><strong>System Prompt:</strong> Base instructions for the model</li>
              <li><strong>Max Tokens:</strong> Maximum response length</li>
            </ul>
          </SubItem>
          
          <SubItem id="ollama-integration" title="Ollama Integration">
            <p>
              Ollama integration allows running open-source models locally:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Requires Ollama to be installed and running locally</li>
              <li>Supports models like Llama 2, Mistral, and other compatible models</li>
              <li>Status indicator shows connection state</li>
              <li>Benefits include privacy (no data leaves your system) and no usage costs</li>
            </ul>
          </SubItem>
          
          <SubItem id="model-recommendations" title="Model Recommendations">
            <p>
              Recommended models by use case:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>Complex Code Analysis:</strong> GPT-4 or Claude 2</li>
              <li><strong>Quick Log Review:</strong> GPT-3.5 Turbo or Claude Instant</li>
              <li><strong>Offline Usage:</strong> Ollama with Llama 2 or Mistral</li>
              <li><strong>Security Analysis:</strong> GPT-4 or specialized security models</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="results" title="5. Analysis Results">
          <p className="mb-3">
            After analysis completes, the application provides structured results in multiple formats.
          </p>
          
          <SubItem id="result-sections" title="Result Sections">
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Analytics Dashboard:</strong> Visual representation of analysis data with interactive charts and metrics
              </li>
              <li>
                <strong>Issues Summary:</strong> Aggregated overview of detected issues categorized by severity and type
              </li>
              <li>
                <strong>Technical Analysis:</strong> Detailed technical evaluation with code references
              </li>
              <li>
                <strong>Simplified Analysis:</strong> Easy-to-understand explanations of issues
              </li>
              <li>
                <strong>Categorized Issues:</strong> Issues grouped by category (syntax, logic, security, performance, etc.)
              </li>
              <li>
                <strong>Recommendations:</strong> Specific suggestions for fixing identified issues
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="issue-categorization" title="Issue Categorization">
            <p>
              Issues are categorized by:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>
                <strong>Severity:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li><strong>Critical:</strong> Severe issues requiring immediate attention</li>
                  <li><strong>High:</strong> Important issues that should be addressed soon</li>
                  <li><strong>Medium:</strong> Issues that should be addressed but aren't urgent</li>
                  <li><strong>Low:</strong> Minor issues or suggestions</li>
                  <li><strong>Info:</strong> Informational notes without specific action required</li>
                </ul>
              </li>
              <li>
                <strong>Type:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li><strong>Syntax:</strong> Grammar or structure problems</li>
                  <li><strong>Logic:</strong> Logical errors or flawed algorithm implementation</li>
                  <li><strong>Security:</strong> Vulnerabilities or security risks</li>
                  <li><strong>Performance:</strong> Inefficient code or bottlenecks</li>
                  <li><strong>Compatibility:</strong> Cross-platform or cross-browser issues</li>
                  <li><strong>Maintainability:</strong> Code quality and maintenance concerns</li>
                  <li><strong>Reliability:</strong> Error handling and edge case concerns</li>
                </ul>
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="code-highlighting" title="Code Highlighting">
            <p>
              The application uses syntax highlighting to make code more readable in results:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Language-specific syntax highlighting</li>
              <li>Error highlighting for problematic code sections</li>
              <li>Line numbers for easy reference</li>
              <li>Context indicators showing relevant surrounding code</li>
            </ul>
          </SubItem>
          
          <SubItem id="issue-navigation" title="Issue Navigation">
            <p>
              Navigate through identified issues using:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Jump-to-issue links in the summary section</li>
              <li>Previous/next issue navigation buttons</li>
              <li>Collapsible issue sections for better overview</li>
              <li>Inline code references that highlight the relevant code when clicked</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="analytics-dashboard" title="6. Analytics Dashboard">
          <p className="mb-3">
            The Analytics Dashboard provides comprehensive visualizations and insights of your analysis data, helping you identify patterns, trends, and key metrics at a glance.
          </p>
          
          <SubItem id="dashboard-overview" title="Dashboard Overview">
            <p>
              The Analytics Dashboard presents a multi-faceted view of your analysis data with interactive charts and metrics designed for both technical and business users:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Enterprise-grade visualization of analysis data</li>
              <li>Interactive charts with filtering and drill-down capabilities</li>
              <li>Time-based analysis with customizable date ranges</li>
              <li>Key performance indicators for quick assessment</li>
              <li>Trend identification and predictive analytics</li>
              <li>Business impact assessment and recommendations</li>
              <li>Automatic light/dark mode support</li>
            </ul>
          </SubItem>
          
          <SubItem id="dashboard-tabs" title="Dashboard Tabs">
            <p>
              The dashboard is organized into four main tabs for different analysis perspectives:
            </p>
            <ul className="list-disc pl-5 space-y-2 mt-2">
              <li>
                <strong>Overview:</strong> High-level summary of key metrics including:
                <ul className="list-disc pl-5 mt-1">
                  <li>Issues by severity (pie chart)</li>
                  <li>Common root causes (bar chart)</li>
                  <li>Issue trends over time (line chart)</li>
                  <li>Key metrics cards (total issues, resolution rate, etc.)</li>
                </ul>
              </li>
              <li>
                <strong>Trends & Forecasts:</strong> Detailed temporal analysis including:
                <ul className="list-disc pl-5 mt-1">
                  <li>Advanced trend analysis with projections</li>
                  <li>Issue distribution by time of day</li>
                  <li>Period comparison with radar charts</li>
                  <li>Data table view of trend information</li>
                  <li>Anomaly detection in issue patterns</li>
                </ul>
              </li>
              <li>
                <strong>Error Patterns:</strong> Error pattern analysis including:
                <ul className="list-disc pl-5 mt-1">
                  <li>Top error patterns with frequency and trend</li>
                  <li>Pattern clustering visualization</li>
                  <li>Impact assessment of different error types</li>
                  <li>Status tracking of identified patterns</li>
                  <li>Pattern detection and classification</li>
                </ul>
              </li>
              <li>
                <strong>Business Impact:</strong> Business perspective including:
                <ul className="list-disc pl-5 mt-1">
                  <li>Estimated business cost of issues</li>
                  <li>Impact breakdown by category (Development, Operations, etc.)</li>
                  <li>Resolution hours estimation</li>
                  <li>Affected systems overview</li>
                  <li>Prioritized recommendations with impact reduction estimates</li>
                </ul>
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="dashboard-features" title="Key Dashboard Features">
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Time Range Selection:</strong> Analyze data across different time periods:
                <ul className="list-disc pl-5 mt-1">
                  <li>Last 24 Hours</li>
                  <li>Last 7 Days</li>
                  <li>Last 30 Days</li>
                  <li>Last 90 Days</li>
                  <li>All Time</li>
                </ul>
              </li>
              <li>
                <strong>Interactive Visualizations:</strong> Engage with the data through:
                <ul className="list-disc pl-5 mt-1">
                  <li>Hover tooltips with detailed information</li>
                  <li>Click interactions for drilling down</li>
                  <li>Filters to focus on specific data segments</li>
                  <li>Responsive design that adapts to window size</li>
                </ul>
              </li>
              <li>
                <strong>Statistical Insights:</strong> Automatic calculation of:
                <ul className="list-disc pl-5 mt-1">
                  <li>Trend analysis with percentage changes</li>
                  <li>Risk score based on severity and volume</li>
                  <li>Resolution rate and time metrics</li>
                  <li>Pattern detection with statistical significance</li>
                </ul>
              </li>
              <li>
                <strong>Projections & Forecasting:</strong> Predictive features including:
                <ul className="list-disc pl-5 mt-1">
                  <li>Issue trend projections (next 7 days)</li>
                  <li>Risk assessment based on trend data</li>
                  <li>Resolution time forecasting</li>
                  <li>Visual distinction between historical and projected data</li>
                </ul>
              </li>
              <li>
                <strong>Comparison Tools:</strong> Compare data between periods:
                <ul className="list-disc pl-5 mt-1">
                  <li>Current vs previous period comparison</li>
                  <li>Radar charts for multi-metric comparison</li>
                  <li>Percentage change indicators</li>
                  <li>Multiple comparison period options (previous 7d, same week last month, etc.)</li>
                </ul>
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="dashboard-export" title="Dashboard Export Options">
            <p>
              Export dashboard visualizations and data in various formats:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>PNG:</strong> Export charts as high-quality images</li>
              <li><strong>PDF:</strong> Export entire dashboard as a PDF report</li>
              <li><strong>CSV:</strong> Export raw data for further analysis in spreadsheet applications</li>
              <li><strong>XLSX:</strong> Export formatted data tables with multiple sheets for different metrics</li>
            </ul>
          </SubItem>
          
          <SubItem id="dashboard-insights" title="Automatic Insights Generation">
            <p>
              The dashboard automatically generates insights based on your data:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Trend direction identification (improving, worsening, stable)</li>
              <li>Risk level assessment (low, moderate, high)</li>
              <li>Pattern correlation detection</li>
              <li>Peak issue time identification</li>
              <li>Business impact assessment</li>
              <li>Prioritized recommendations based on data analysis</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="filtering" title="7. Search & Filtering">
          <p className="mb-3">
            The application provides powerful search and filtering capabilities to help you focus on specific aspects of the analysis.
          </p>
          
          <SubItem id="search-functionality" title="Search Functionality">
            <ul className="list-disc pl-5 space-y-1">
              <li>Full-text search across all analysis results</li>
              <li>Highlighted search term occurrences</li>
              <li>Search within specific sections only</li>
              <li>Regular expression support for advanced searching</li>
            </ul>
          </SubItem>
          
          <SubItem id="severity-filters" title="Severity Filters">
            <p>
              Filter issues by severity level:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Critical issues only</li>
              <li>High and above</li>
              <li>Medium and above</li>
              <li>All issues including low and informational</li>
            </ul>
          </SubItem>
          
          <SubItem id="type-filters" title="Type Filters">
            <p>
              Filter issues by type:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Syntax issues</li>
              <li>Logic issues</li>
              <li>Security vulnerabilities</li>
              <li>Performance concerns</li>
              <li>Compatibility issues</li>
              <li>Maintainability concerns</li>
              <li>Reliability issues</li>
            </ul>
          </SubItem>
          
          <SubItem id="combined-filters" title="Combined Filtering">
            <p>
              Combine multiple filters for precise results:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Multiple severity levels (e.g., Critical AND High)</li>
              <li>Multiple issue types (e.g., Security AND Performance)</li>
              <li>Text search with type/severity filters</li>
              <li>Save filter combinations for future use</li>
            </ul>
          </SubItem>
          
          <SubItem id="filter-presets" title="Filter Presets">
            <p>
              Common filter presets include:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>Security Focus:</strong> All security issues regardless of severity</li>
              <li><strong>Critical Issues:</strong> All critical issues regardless of type</li>
              <li><strong>Quick Wins:</strong> High-impact issues with low effort fixes</li>
              <li><strong>Performance Optimization:</strong> All performance-related issues</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="export" title="8. Sharing & Exporting">
          <p className="mb-3">
            The application provides multiple options for sharing and exporting analysis results.
          </p>
          
          <SubItem id="export-formats" title="Export Formats">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Text (.txt):</strong> Plain text format with basic formatting</li>
              <li><strong>Markdown (.md):</strong> Formatted text with code blocks and headers</li>
              <li><strong>HTML (.html):</strong> Web page with full formatting and interactive elements</li>
              <li><strong>JSON (.json):</strong> Structured data format for programmatic processing</li>
              <li><strong>PDF (.pdf):</strong> Document format with preserved formatting, suitable for printing</li>
              <li><strong>CSV (.csv):</strong> Tabular format focusing on issues list</li>
            </ul>
          </SubItem>
          
          <SubItem id="smart-copy" title="Smart Copy Feature">
            <p>
              The Smart Copy feature provides enhanced clipboard operations with multiple format options:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>Format Options:</strong> Copy content as plain text, Markdown, HTML, or JSON</li>
              <li><strong>Section-Specific Copying:</strong> Copy individual sections (technical analysis, simplified explanation, suggested solutions)</li>
              <li><strong>Format Preservation:</strong> HTML export maintains all highlighting and formatting seen in the interface</li>
              <li><strong>Format Memory:</strong> Remembers your preferred format for future copy operations</li>
              <li><strong>Visual Feedback:</strong> Provides clear confirmation when content is copied</li>
            </ul>
            <p className="mt-2">
              Each section of the analysis includes a dedicated copy button that provides these smart copy options through a dropdown menu.
            </p>
          </SubItem>
          
          <SubItem id="clipboard-operations" title="Clipboard Operations">
            <ul className="list-disc pl-5 space-y-1">
              <li>Copy entire analysis to clipboard</li>
              <li>Copy specific sections (technical, simplified, recommendations)</li>
              <li>Copy individual code blocks with formatting preserved</li>
              <li>Copy issue summaries in table format</li>
              <li>Copy with or without syntax highlighting</li>
            </ul>
          </SubItem>
          
          <SubItem id="share-url" title="Share URL Generation">
            <p>
              Generate shareable URLs that contain:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Complete analysis results (encrypted for privacy)</li>
              <li>Current filter settings</li>
              <li>Selected view modes</li>
              <li>Optional password protection for sensitive content</li>
              <li>Expiration settings (1 day, 1 week, 1 month, never)</li>
            </ul>
          </SubItem>
          
          <SubItem id="integration-options" title="Integration Options">
            <p>
              Export directly to external services:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li><strong>GitHub:</strong> Create issues or comments from analysis results</li>
              <li><strong>Jira:</strong> Create tickets with detailed analysis</li>
              <li><strong>Slack:</strong> Share summaries to channels or direct messages</li>
              <li><strong>Email:</strong> Send analysis reports via configured email client</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="history" title="9. Analysis History">
          <p className="mb-3">
            The application maintains a history of previous analyses for reference and comparison.
          </p>
          
          <SubItem id="history-storage" title="History Storage">
            <ul className="list-disc pl-5 space-y-1">
              <li>Analyses stored in browser's localStorage by default</li>
              <li>Optional cloud storage with user account</li>
              <li>Each entry includes metadata and full analysis results</li>
              <li>Storage limitations based on browser (typically up to 5MB for localStorage)</li>
            </ul>
          </SubItem>
          
          <SubItem id="history-management" title="History Management">
            <ul className="list-disc pl-5 space-y-1">
              <li>View complete analysis history</li>
              <li>Filter history by date, file type, or keywords</li>
              <li>Delete individual history entries</li>
              <li>Clear entire history</li>
              <li>Export history to backup file</li>
              <li>Import history from backup file</li>
            </ul>
          </SubItem>
          
          <SubItem id="history-viewing" title="Viewing Past Analyses">
            <ul className="list-disc pl-5 space-y-1">
              <li>Load any past analysis with complete results</li>
              <li>Compare current analysis with historical ones</li>
              <li>Track changes in specific issues over time</li>
              <li>Restore analysis state including filters and view settings</li>
            </ul>
          </SubItem>
          
          <SubItem id="history-limits" title="History Limitations">
            <ul className="list-disc pl-5 space-y-1">
              <li>Default storage limit: 20 most recent analyses</li>
              <li>Configurable limit in settings (5-50 entries)</li>
              <li>Oldest entries automatically removed when limit reached</li>
              <li>Storage space warning when approaching browser limits</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="patterns" title="10. Pattern Insights">
          <p className="mb-3">
            One of the most powerful features is the ability to detect patterns across multiple analyses to identify recurring issues or trends.
          </p>
          
          <SubItem id="pattern-types" title="Types of Patterns Detected">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Recurring Errors:</strong> Same or similar errors appearing across multiple files</li>
              <li><strong>Time-based Patterns:</strong> Issues that occur at specific intervals</li>
              <li><strong>Code Structure Patterns:</strong> Recurring problematic code constructs</li>
              <li><strong>Error Frequency:</strong> Tracking how often specific error types appear</li>
              <li><strong>Error Correlations:</strong> Related errors that tend to appear together</li>
            </ul>
          </SubItem>
          
          <SubItem id="pattern-algorithms" title="Pattern Detection Algorithms">
            <p>
              The application uses several algorithms to detect patterns:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Text similarity matching for error messages</li>
              <li>Regular expression-based pattern detection</li>
              <li>Frequency analysis across time periods</li>
              <li>Code structure similarity detection</li>
              <li>Category correlation analysis</li>
            </ul>
          </SubItem>
          
          <SubItem id="pattern-insights" title="Pattern Insights Modal">
            <p>
              The Pattern Insights modal provides:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Visualization of detected patterns</li>
              <li>Frequency counts for recurring issues</li>
              <li>Timeline view for temporal patterns</li>
              <li>Suggestions for addressing root causes</li>
              <li>Links to related analyses for context</li>
            </ul>
          </SubItem>
          
          <SubItem id="pattern-suggestions" title="Pattern-based Suggestions">
            <p>
              Based on detected patterns, the system generates tailored suggestions:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Root cause analysis for recurring errors</li>
              <li>Suggested system-level fixes for widespread issues</li>
              <li>Investigation strategies for time-based patterns</li>
              <li>Code refactoring suggestions for structural patterns</li>
              <li>Testing recommendations for reliability issues</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="troubleshooting" title="11. Troubleshooting Wizard">
          <p className="mb-3">
            The Troubleshooting Wizard provides guided, step-by-step assistance for resolving identified issues.
          </p>
          
          <SubItem id="wizard-workflow" title="Wizard Workflow">
            <ol className="list-decimal pl-5 space-y-1">
              <li>Select an issue to troubleshoot</li>
              <li>Review detailed explanation of the issue</li>
              <li>Follow guided diagnostic steps</li>
              <li>Implement suggested solutions</li>
              <li>Verify the fix with validation guidance</li>
            </ol>
          </SubItem>
          
          <SubItem id="wizard-features" title="Wizard Features">
            <ul className="list-disc pl-5 space-y-1">
              <li>Interactive step-by-step guidance</li>
              <li>Contextual code examples</li>
              <li>Visual diagrams for complex issues</li>
              <li>Alternative solution paths for different scenarios</li>
              <li>Progress tracking through the resolution process</li>
            </ul>
          </SubItem>
          
          <SubItem id="solution-types" title="Types of Solutions Provided">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Code Fixes:</strong> Specific code changes to resolve issues</li>
              <li><strong>Configuration Changes:</strong> Adjustments to configuration files</li>
              <li><strong>Dependency Updates:</strong> Version updates or package replacements</li>
              <li><strong>Architecture Recommendations:</strong> Structural changes to code organization</li>
              <li><strong>Testing Strategies:</strong> Approaches to validate fixes</li>
            </ul>
          </SubItem>
          
          <SubItem id="wizard-navigation" title="Wizard Navigation">
            <ul className="list-disc pl-5 space-y-1">
              <li>Forward/back navigation between steps</li>
              <li>Save progress and return later</li>
              <li>Skip certain steps when not applicable</li>
              <li>Branching paths based on your specific scenario</li>
              <li>Quick exit with solution summary</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="settings" title="12. Application Settings">
          <p className="mb-3">
            The Settings modal provides access to various configuration options to customize the application behavior.
          </p>
          
          <SubItem id="general-settings" title="General Settings">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Theme:</strong> Light, dark, or system preference</li>
              <li><strong>Language:</strong> Interface language preference</li>
              <li><strong>Default Analysis Type:</strong> Set preferred analysis mode</li>
              <li><strong>Default Model:</strong> Set preferred AI model</li>
              <li><strong>Stream Mode Default:</strong> Enable/disable streaming by default</li>
            </ul>
          </SubItem>
          
          <SubItem id="analysis-settings-config" title="Analysis Settings">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>Max Tokens Per Chunk:</strong> 1000-8000 (default: 4000)</li>
              <li><strong>Timeout:</strong> 10-300 seconds (default: 60)</li>
              <li><strong>Chunk Overlap:</strong> 0-500 tokens (default: 200)</li>
              <li><strong>Context Window:</strong> 1-10 lines (default: 3)</li>
              <li><strong>Analysis Depth:</strong> Quick, Standard, or Deep (affects processing time)</li>
            </ul>
          </SubItem>
          
          <SubItem id="model-config" title="Model Configuration">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>API Keys:</strong> Configure API keys for different providers</li>
              <li><strong>Base URLs:</strong> Set custom endpoints for API providers</li>
              <li><strong>Model Parameters:</strong> Configure default temperature, top_p, etc.</li>
              <li><strong>Ollama Settings:</strong> Configure local Ollama connection</li>
              <li><strong>System Prompts:</strong> Customize base instructions for models</li>
            </ul>
          </SubItem>
          
          <SubItem id="storage-settings" title="Storage Settings">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>History Size:</strong> Number of analyses to keep (5-50)</li>
              <li><strong>Storage Location:</strong> Browser localStorage or cloud account</li>
              <li><strong>Auto-clear Threshold:</strong> When to automatically remove old analyses</li>
              <li><strong>Export/Import:</strong> Backup and restore application data</li>
              <li><strong>Clear All Data:</strong> Remove all stored analyses and settings</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="accessibility" title="13. Accessibility Features">
          <p className="mb-3">
            The application includes several accessibility features to ensure usability for all users.
          </p>
          
          <SubItem id="keyboard-navigation" title="Keyboard Navigation">
            <ul className="list-disc pl-5 space-y-1">
              <li>Full keyboard navigation support with focus indicators</li>
              <li>Shortcut keys for common operations</li>
              <li>Focus trapping in modals</li>
              <li>Skip to content link for screen readers</li>
              <li>Arrow key navigation in results</li>
            </ul>
          </SubItem>
          
          <SubItem id="screen-reader" title="Screen Reader Support">
            <ul className="list-disc pl-5 space-y-1">
              <li>ARIA attributes throughout the interface</li>
              <li>Proper heading hierarchy</li>
              <li>Alt text for all images and icons</li>
              <li>Announcements for dynamic content changes</li>
              <li>Descriptive labels for all interactive elements</li>
            </ul>
          </SubItem>
          
          <SubItem id="visual-accessibility" title="Visual Accessibility">
            <ul className="list-disc pl-5 space-y-1">
              <li>High contrast mode option</li>
              <li>Adjustable font size settings</li>
              <li>Color blind friendly color schemes</li>
              <li>Customizable contrast ratios</li>
              <li>Focus indicators with sufficient visibility</li>
            </ul>
          </SubItem>
          
          <SubItem id="cognitive-accessibility" title="Cognitive Accessibility">
            <ul className="list-disc pl-5 space-y-1">
              <li>Simple language option for error messages and instructions</li>
              <li>Progress indicators for all operations</li>
              <li>Consistent interface patterns</li>
              <li>Simplified view option with reduced visual complexity</li>
              <li>Step-by-step guidance for complex operations</li>
            </ul>
          </SubItem>
        </Section>

        <Section id="keyboard-shortcuts" title="14. Keyboard Shortcuts">
          <p className="mb-3">
            The application provides keyboard shortcuts for efficient navigation and operation.
          </p>
          
          <div className="grid grid-cols-2 gap-2">
            <div>
              <h3 className="font-bold mb-2 dark:text-gray-200">General</h3>
              <ul className="space-y-1 dark:text-gray-300">
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">?</span> - Show keyboard shortcuts</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+/</span> - Show keyboard shortcuts</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+S</span> - Open settings</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+H</span> - Toggle history</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+D</span> - Toggle dark mode</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-2 dark:text-gray-200">File Handling</h3>
              <ul className="space-y-1 dark:text-gray-300">
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+O</span> - Open file</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+V</span> - Paste from clipboard</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Escape</span> - Clear selected file</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-2 dark:text-gray-200">Analysis</h3>
              <ul className="space-y-1 dark:text-gray-300">
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+Enter</span> - Start analysis</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+.</span> - Cancel analysis</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+Shift+E</span> - Export results</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+Shift+S</span> - Share results</li>
              </ul>
            </div>
            
            <div>
              <h3 className="font-bold mb-2 dark:text-gray-200">Navigation</h3>
              <ul className="space-y-1 dark:text-gray-300">
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Ctrl+F</span> - Focus search</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Alt+N</span> - Next issue</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Alt+P</span> - Previous issue</li>
                <li><span className="font-mono bg-gray-200 dark:bg-gray-700 px-1">Alt+1-5</span> - Filter by severity</li>
              </ul>
            </div>
          </div>
        </Section>

        <Section id="troubleshooting-app" title="15. Troubleshooting the Application">
          <p className="mb-3">
            If you encounter issues with the application itself, here are some common problems and solutions.
          </p>
          
          <SubItem id="common-issues" title="Common Issues">
            <ul className="list-disc pl-5 space-y-2">
              <li>
                <strong>Analysis fails to start:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>Check your internet connection</li>
                  <li>Verify API keys are configured correctly</li>
                  <li>Ensure file size is within limits</li>
                  <li>Try a different AI model provider</li>
                </ul>
              </li>
              <li>
                <strong>Ollama connection issues:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>Verify Ollama is running locally</li>
                  <li>Check the Ollama URL in settings</li>
                  <li>Ensure the selected model is installed in Ollama</li>
                  <li>Restart Ollama service</li>
                </ul>
              </li>
              <li>
                <strong>Analysis timeout:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>Increase timeout setting in advanced settings</li>
                  <li>Reduce file size or split into smaller files</li>
                  <li>Try a faster model (e.g., GPT-3.5 instead of GPT-4)</li>
                  <li>Disable streaming mode</li>
                </ul>
              </li>
              <li>
                <strong>History not loading:</strong>
                <ul className="list-disc pl-5 mt-1">
                  <li>Check browser storage permissions</li>
                  <li>Clear browser cache and reload</li>
                  <li>Try importing from backup if available</li>
                  <li>Check for localStorage quota limits</li>
                </ul>
              </li>
            </ul>
          </SubItem>
          
          <SubItem id="browser-compatibility" title="Browser Compatibility">
            <p>
              The application is fully supported on:
            </p>
            <ul className="list-disc pl-5 space-y-1 mt-2">
              <li>Chrome 80+</li>
              <li>Firefox 78+</li>
              <li>Safari 14+</li>
              <li>Edge 80+</li>
              <li>Opera 67+</li>
            </ul>
            <p className="mt-2">
              Limited support on older browsers or mobile browsers.
            </p>
          </SubItem>
          
          <SubItem id="error-messages" title="Common Error Messages">
            <ul className="list-disc pl-5 space-y-1">
              <li><strong>"API key not configured":</strong> Add API key in settings</li>
              <li><strong>"File too large":</strong> Reduce file size or increase chunk size setting</li>
              <li><strong>"Model not available":</strong> Select a different model or check provider status</li>
              <li><strong>"Connection to Ollama failed":</strong> Check Ollama installation and configuration</li>
              <li><strong>"Storage quota exceeded":</strong> Clear history or reduce history size limit</li>
            </ul>
          </SubItem>
          
          <SubItem id="reporting-bugs" title="Reporting Bugs">
            <p>
              If you encounter persistent issues:
            </p>
            <ol className="list-decimal pl-5 space-y-1 mt-2">
              <li>Check the console for error messages (F12 in most browsers)</li>
              <li>Take screenshots of any error messages</li>
              <li>Note the steps to reproduce the issue</li>
              <li>Include browser and OS information</li>
              <li>Report via the Help → Report Bug menu or email support@onemoreinsights.com</li>
            </ol>
          </SubItem>
        </Section>

        <Section id="tips-tricks" title="16. Tips & Best Practices">
          <p className="mb-3">
            Get the most out of the application with these tips and best practices.
          </p>
          
          <SubItem id="file-preparation" title="File Preparation">
            <ul className="list-disc pl-5 space-y-1">
              <li>Format code files before analysis for better results</li>
              <li>For large files, analyze the most critical sections separately</li>
              <li>Include necessary context files when analyzing dependencies</li>
              <li>Clean log files of sensitive information before uploading</li>
              <li>For logs, include timestamps and thread/process IDs when available</li>
            </ul>
          </SubItem>
          
          <SubItem id="model-selection" title="Model Selection Tips">
            <ul className="list-disc pl-5 space-y-1">
              <li>Use GPT-4 or Claude 2 for complex analysis needs</li>
              <li>Use faster models like GPT-3.5 for initial screening</li>
              <li>For privacy-sensitive code, use Ollama with local models</li>
              <li>Specialized models often work better for certain languages (e.g., Codellama for code)</li>
              <li>Balance between model quality and response time based on your needs</li>
            </ul>
          </SubItem>
          
          <SubItem id="workflow-tips" title="Workflow Tips">
            <ul className="list-disc pl-5 space-y-1">
              <li>Start with the Analytics Dashboard for a high-level overview</li>
              <li>Use trend analysis to spot recurring or worsening issues</li>
              <li>Follow up with detailed technical analysis on critical sections</li>
              <li>Use pattern insights after multiple related analyses</li>
              <li>Export dashboard visualizations for management presentations</li>
              <li>Use projections to plan resources for issue resolution</li>
              <li>Compare periods to validate improvement initiatives</li>
              <li>Re-analyze files after making changes to verify improvements</li>
            </ul>
          </SubItem>
          
          <SubItem id="performance-tips" title="Performance Optimization">
            <ul className="list-disc pl-5 space-y-1">
              <li>Clear history periodically to free up storage</li>
              <li>Use Chrome or Firefox for best performance</li>
              <li>Close other tabs and applications when analyzing large files</li>
              <li>Disable stream mode for more efficient token usage</li>
              <li>Adjust chunk size based on file complexity</li>
            </ul>
          </SubItem>
          
          <SubItem id="dashboard-tips" title="Analytics Dashboard Tips">
            <ul className="list-disc pl-5 space-y-1">
              <li>Use time range selectors to focus on relevant periods</li>
              <li>Enable projections when planning future work</li>
              <li>Use the comparison feature to measure improvements</li>
              <li>Export dashboard sections for management reports</li>
              <li>Check the Business Impact tab when prioritizing issues</li>
              <li>Use pattern clustering to identify related issues</li>
              <li>Review trends periodically to spot emerging problems</li>
              <li>Filter issue types on trend charts for focused analysis</li>
            </ul>
          </SubItem>
        </Section>
      </div>
      
      <div className="mt-8 pt-6 border-t border-gray-200 dark:border-gray-700">
        <p className="text-sm text-gray-500 dark:text-gray-400 text-center">
          One More Thing Insights Help Guide • v2.3.1 • Last Updated: April 2025
        </p>
      </div>
    </div>
  );
};

export default HelpComponent;