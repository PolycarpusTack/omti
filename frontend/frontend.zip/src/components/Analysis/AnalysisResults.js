// src/components/Analysis/AnalysisResults.js
import React, { useState, useEffect } from 'react';
import CollapsibleSection from '../UI/CollapsibleSection';
import CopyMenu from '../UI/CopyMenu';
import TagSelector from '../UI/TagSelector';
import { determineSeverity, getSeverityProperties, highlightAll } from '../../utils/highlighter';
import { copyFormatPreference } from '../../utils/copyUtils';

const AnalysisResults = ({
  analyses = [],
  filteredAnalyses = [],
  totalCount = 0,
  copySuccess,
  onCopy,
  onStartTroubleshooting,
  highlightErrors
}) => {
  const [highlightOptions, setHighlightOptions] = useState({
    severity: true,
    stackTraces: true,
    technicalTerms: true,
    pathsAndUrls: true,
    dateTimes: true
  });
  
  const [copyFeedback, setCopyFeedback] = useState(null);
  
  // Toggle highlight options
  const toggleHighlightOption = (option) => {
    setHighlightOptions(prev => ({
      ...prev,
      [option]: !prev[option]
    }));
  };
  
  // Handle copy success feedback
  useEffect(() => {
    if (copySuccess) {
      setCopyFeedback({
        message: 'Copied to clipboard!',
        type: 'success'
      });
      
      const timer = setTimeout(() => {
        setCopyFeedback(null);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [copySuccess]);
  
  // Handle copy function with feedback
  const handleCopy = (id) => {
    onCopy(id);
  };
  
  // If no analyses, show placeholder
  if (!analyses.length) {
    return null;
  }
  
  // Handle crash vs standard analysis display
  const isCrashAnalysis = analyses[0]?.crash_resolution_report && analyses[0]?.diagnostic_overview_report;
  
  return (
    <div className="mt-8">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
          Analysis Results
          {totalCount > 0 && (
            <span className="ml-2 text-sm font-normal text-gray-500 dark:text-gray-400">
              {filteredAnalyses.length} of {totalCount} chunk{totalCount !== 1 ? 's' : ''}
            </span>
          )}
        </h2>
        
        {/* Highlight options control */}
        <div className="flex items-center space-x-3">
          <span className="text-sm text-gray-600 dark:text-gray-300">Highlighting:</span>
          
          <div className="flex items-center space-x-2">
            <button
              className={`p-1 rounded ${highlightOptions.severity ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}
              onClick={() => toggleHighlightOption('severity')}
              title="Highlight severity levels"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className={`p-1 rounded ${highlightOptions.stackTraces ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}
              onClick={() => toggleHighlightOption('stackTraces')}
              title="Highlight stack traces"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className={`p-1 rounded ${highlightOptions.technicalTerms ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}
              onClick={() => toggleHighlightOption('technicalTerms')}
              title="Highlight technical terms"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.316 3.051a1 1 0 01.633 1.265l-4 12a1 1 0 11-1.898-.632l4-12a1 1 0 011.265-.633zM5.707 6.293a1 1 0 010 1.414L3.414 10l2.293 2.293a1 1 0 11-1.414 1.414l-3-3a1 1 0 010-1.414l3-3a1 1 0 011.414 0zm8.586 0a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 11-1.414-1.414L16.586 10l-2.293-2.293a1 1 0 010-1.414z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className={`p-1 rounded ${highlightOptions.pathsAndUrls ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}
              onClick={() => toggleHighlightOption('pathsAndUrls')}
              title="Highlight paths and URLs"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
              </svg>
            </button>
            
            <button
              className={`p-1 rounded ${highlightOptions.dateTimes ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-300'}`}
              onClick={() => toggleHighlightOption('dateTimes')}
              title="Highlight dates and times"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Copy feedback notification */}
      {copyFeedback && (
        <div className={`fixed bottom-4 right-4 px-4 py-2 rounded-md shadow-lg ${copyFeedback.type === 'success' ? 'bg-green-500' : 'bg-red-500'} text-white`}>
          {copyFeedback.message}
        </div>
      )}
      
      <div className="space-y-6">
        {isCrashAnalysis ? (
          <CrashAnalysisResult 
            analysis={analyses[0]}
            copySuccess={copySuccess}
            onCopy={handleCopy}
            onStartTroubleshooting={onStartTroubleshooting}
            highlightOptions={highlightOptions}
          />
        ) : (
          filteredAnalyses.map((analysis) => (
            <ChunkAnalysisResult 
              key={`chunk-${analysis.chunk || 0}`}
              analysis={analysis}
              copySuccess={copySuccess}
              onCopy={handleCopy}
              onStartTroubleshooting={onStartTroubleshooting}
              highlightOptions={highlightOptions}
            />
          ))
        )}
      </div>
    </div>
  );
};

// Component to display crash analysis results
const CrashAnalysisResult = ({ 
  analysis, 
  copySuccess, 
  onCopy, 
  onStartTroubleshooting, 
  highlightOptions 
}) => {
  // Create a unique ID for the analysis
  const analysisId = analysis.timestamp 
    ? `crash-${new Date(analysis.timestamp).getTime()}`
    : `crash-${Date.now()}`;
  
  // Determine severity from crash resolution report
  const overallSeverity = analysis.crash_resolution_report
    ? determineSeverity(analysis.crash_resolution_report)
    : 'critical'; // Default to critical for crash analysis
    
  // Determine severity from suggested solutions
  const solutionsSeverity = analysis.suggested_solutions
    ? determineSeverity(analysis.suggested_solutions)
    : 'info';
  
  return (
    <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700">
      {/* Header */}
      <div className="p-4 flex justify-between items-start border-b border-gray-200 dark:border-gray-700">
        <div>
          <h3 className="text-lg font-medium text-gray-900 dark:text-white">
            Crash Analysis
          </h3>
          {analysis.timestamp && (
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Generated on {new Date(analysis.timestamp).toLocaleString()}
            </p>
          )}
        </div>
        
        <div className="flex space-x-2">
          <TagSelector analysisId={analysisId} />
          
          <button
            onClick={() => onStartTroubleshooting(analysis)}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Troubleshoot
          </button>
          
          {/* Full analysis copy button */}
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            highlightOptions={highlightOptions}
          />
        </div>
      </div>
      
      {/* Crash Resolution Report */}
      <CollapsibleSection
        title="Crash Resolution Report"
        defaultOpen={true}
        severity="critical"
      >
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={
            highlightAll(analysis.crash_resolution_report, highlightOptions)
          }
        />
        
        <div className="mt-4 flex justify-end">
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            section="crash_resolution_report"
            highlightOptions={highlightOptions}
          />
        </div>
      </CollapsibleSection>
      
      {/* Diagnostic Overview Report */}
      <CollapsibleSection
        title="Diagnostic Overview Report"
        defaultOpen={false}
        severity={overallSeverity}
      >
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={
            highlightAll(analysis.diagnostic_overview_report, highlightOptions)
          }
        />
        
        <div className="mt-4 flex justify-end">
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            section="diagnostic_overview_report"
            highlightOptions={highlightOptions}
          />
        </div>
      </CollapsibleSection>
      
      {/* Suggested Solutions */}
      <CollapsibleSection
        title="Suggested Solutions"
        defaultOpen={true}
        severity={solutionsSeverity}
      >
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={
            highlightAll(analysis.suggested_solutions, highlightOptions)
          }
        />
        
        <div className="mt-4 flex justify-end">
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            section="suggested_solutions"
            highlightOptions={highlightOptions}
          />
        </div>
      </CollapsibleSection>
    </div>
  );
};

// Component to display chunk analysis results
const ChunkAnalysisResult = ({ 
  analysis, 
  copySuccess, 
  onCopy, 
  onStartTroubleshooting, 
  highlightOptions 
}) => {
  // Create a unique ID for the analysis
  const analysisId = analysis.timestamp 
    ? `chunk-${analysis.chunk}-${new Date(analysis.timestamp).getTime()}`
    : `chunk-${analysis.chunk}-${Date.now()}`;
  
  // Determine severity from technical analysis
  const technicalSeverity = analysis.technical_analysis
    ? determineSeverity(analysis.technical_analysis)
    : 'info';
  
  // Determine severity from simplified analysis
  const simplifiedSeverity = analysis.simplified_analysis
    ? determineSeverity(analysis.simplified_analysis)
    : 'info';
  
  // Determine severity from suggested solutions
  const solutionsSeverity = analysis.suggested_solutions
    ? determineSeverity(analysis.suggested_solutions)
    : 'info';
  
  // Determine overall severity
  const overallSeverity = 
    technicalSeverity === 'critical' || simplifiedSeverity === 'critical' ? 'critical' :
    technicalSeverity === 'error' || simplifiedSeverity === 'error' ? 'error' :
    technicalSeverity === 'warning' || simplifiedSeverity === 'warning' ? 'warning' :
    'info';
  
  const severityProps = getSeverityProperties(overallSeverity);
  
  return (
    <div className={`bg-white dark:bg-gray-800 shadow-sm rounded-lg overflow-hidden border ${severityProps.border}`}>
      {/* Header */}
      <div className={`p-4 flex justify-between items-start border-b ${severityProps.border}`}>
        <div>
          <div className="flex items-center">
            <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium mr-2 ${severityProps.background} ${severityProps.color}`}>
              {severityProps.label}
            </span>
            <h3 className="text-lg font-medium text-gray-900 dark:text-white">
              Chunk {analysis.chunk} of {analysis.total_chunks}
            </h3>
          </div>
          {analysis.timestamp && (
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Generated on {new Date(analysis.timestamp).toLocaleString()}
            </p>
          )}
        </div>
        
        <div className="flex space-x-2">
          <TagSelector analysisId={analysisId} />
          
          <button
            onClick={() => onStartTroubleshooting(analysis)}
            className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Troubleshoot
          </button>
          
          {/* Full analysis copy button */}
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            highlightOptions={highlightOptions}
          />
        </div>
      </div>
      
      {/* Technical Analysis */}
      <CollapsibleSection
        title="Technical Analysis"
        defaultOpen={false}
        severity={technicalSeverity}
      >
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={
            highlightAll(analysis.technical_analysis, highlightOptions)
          }
        />
        
        <div className="mt-4 flex justify-end">
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            section="technical_analysis"
            highlightOptions={highlightOptions}
          />
        </div>
      </CollapsibleSection>
      
      {/* Simplified Analysis */}
      <CollapsibleSection
        title="Simplified Explanation"
        defaultOpen={true}
        severity={simplifiedSeverity}
      >
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={
            highlightAll(analysis.simplified_analysis, highlightOptions)
          }
        />
        
        <div className="mt-4 flex justify-end">
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            section="simplified_analysis"
            highlightOptions={highlightOptions}
          />
        </div>
      </CollapsibleSection>
      
      {/* Suggested Solutions */}
      <CollapsibleSection
        title="Suggested Solutions"
        defaultOpen={true}
        severity={solutionsSeverity}
      >
        <div 
          className="prose dark:prose-invert max-w-none"
          dangerouslySetInnerHTML={
            highlightAll(analysis.suggested_solutions, highlightOptions)
          }
        />
        
        <div className="mt-4 flex justify-end">
          <CopyMenu
            analysis={analysis}
            onCopy={onCopy}
            section="suggested_solutions"
            highlightOptions={highlightOptions}
          />
        </div>
      </CollapsibleSection>
    </div>
  );
};

export default AnalysisResults;