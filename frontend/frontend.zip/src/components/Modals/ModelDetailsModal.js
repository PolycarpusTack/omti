// src/components/ModelDetailsModal.js
import React, { useState } from 'react';

const ModelDetailsModal = ({ 
  model, 
  isOpen, 
  onClose, 
  onSelectModel, 
  isSelected, 
  onUpdateSettings
}) => {
  // State for model-specific settings
  const [settings, setSettings] = useState({
    temperature: model.settings?.temperature || 0.7,
    topP: model.settings?.topP || 0.9,
    maxTokensPerChunk: model.settings?.maxTokensPerChunk || 4000,
    maxOutputTokens: model.settings?.maxOutputTokens || 2000,
    frequencyPenalty: model.settings?.frequencyPenalty || 0,
    presencePenalty: model.settings?.presencePenalty || 0,
    timeout: model.settings?.timeout || 300
  });

  // Handle settings changes
  const handleSettingChange = (key, value) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    
    // Only apply changes if this is the currently selected model
    if (isSelected) {
      onUpdateSettings(model.id, newSettings);
    }
  };

  // Save settings when closing the modal
  const handleClose = () => {
    // Update the model settings on close, even if not selected
    onUpdateSettings(model.id, settings);
    onClose();
  };

  // Handle benchmarking
  const [benchmarking, setBenchmarking] = useState(false);
  const [benchmarkResults, setBenchmarkResults] = useState(null);

  const runBenchmark = () => {
    setBenchmarking(true);
    // This would actually connect to your backend to run a quick benchmark
    // For demo, we'll simulate it
    setTimeout(() => {
      setBenchmarking(false);
      setBenchmarkResults({
        inferenceTime: (Math.random() * 2 + 0.5).toFixed(2),
        tokensPerSecond: Math.floor(Math.random() * 50 + 20),
        memoryUsage: `${(Math.random() * 5 + 2).toFixed(1)} GB`
      });
    }, 3000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white dark:bg-gray-800 rounded-lg p-6 max-w-4xl w-full max-h-[90vh] overflow-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center">
            <div className={`w-3 h-3 rounded-full ${
              model.status === 'healthy' ? 'bg-green-500' : 
              model.status === 'degraded' ? 'bg-yellow-500' : 
              'bg-red-500'
            } mr-2`}></div>
            <h2 className="text-xl font-bold dark:text-gray-100">{model.name}</h2>
            
            {model.provider && (
              <span className="ml-2 px-2 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 text-xs rounded-full">
                {model.provider === 'openai' ? 'OpenAI' : model.provider}
              </span>
            )}
          </div>
          <button 
            onClick={handleClose}
            className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {/* Two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column - Model information */}
          <div className="lg:col-span-1 space-y-6">
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-3 dark:text-gray-200">Model Information</h3>
              
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Size</div>
                  <div className="font-medium dark:text-gray-200">{model.size} parameters</div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Specialization</div>
                  <div className="font-medium dark:text-gray-200">{model.specialization}</div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Status</div>
                  <div className="flex items-center">
                    <div className={`w-2 h-2 rounded-full ${
                      model.status === 'healthy' ? 'bg-green-500' : 
                      model.status === 'degraded' ? 'bg-yellow-500' : 
                      'bg-red-500'
                    } mr-1`}></div>
                    <span className="font-medium dark:text-gray-200 capitalize">{model.status}</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Performance metrics */}
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-3 dark:text-gray-200">Performance Metrics</h3>
              
              <div className="space-y-4">
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Avg Response Time</div>
                  <div className="font-medium dark:text-gray-200">{model.avgResponseTime?.toFixed(1) || '-'} seconds</div>
                </div>
                
                <div>
                  <div className="text-sm text-gray-500 dark:text-gray-400">Throughput</div>
                  <div className="font-medium dark:text-gray-200">{model.throughput?.toFixed(1) || '-'} tokens/sec</div>
                </div>
              </div>
              
              {/* Benchmark section */}
              <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-600">
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-sm font-medium text-gray-500 dark:text-gray-400">Quick Benchmark</h4>
                  <button 
                    onClick={runBenchmark}
                    disabled={benchmarking}
                    className={`text-xs px-2 py-1 rounded ${
                      benchmarking 
                        ? 'bg-gray-300 text-gray-600 dark:bg-gray-600 dark:text-gray-400' 
                        : 'bg-blue-100 text-blue-700 hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300'
                    }`}
                  >
                    {benchmarking ? 'Running...' : 'Run Test'}
                  </button>
                </div>
                
                {benchmarking && (
                  <div className="flex justify-center py-2">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-blue-500"></div>
                  </div>
                )}
                
                {benchmarkResults && !benchmarking && (
                  <div className="space-y-2 mt-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">Inference Time:</span>
                      <span className="font-medium dark:text-gray-200">{benchmarkResults.inferenceTime}s</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">Tokens/Second:</span>
                      <span className="font-medium dark:text-gray-200">{benchmarkResults.tokensPerSecond}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500 dark:text-gray-400">Memory Usage:</span>
                      <span className="font-medium dark:text-gray-200">{benchmarkResults.memoryUsage}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
            
            {/* Description */}
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-2 dark:text-gray-200">Description</h3>
              <p className="text-gray-700 dark:text-gray-300">
                {model.description}
              </p>
            </div>
          </div>
          
          {/* Right column - Settings and more info */}
          <div className="lg:col-span-2 space-y-6">
            {/* Model settings */}
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-4 dark:text-gray-200">Model Settings</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Temperature */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Temperature</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="0" 
                      max="1" 
                      step="0.1"
                      value={settings.temperature}
                      onChange={(e) => handleSettingChange('temperature', parseFloat(e.target.value))}
                      className="flex-grow"
                    />
                    <span className="w-8 text-sm text-gray-700 dark:text-gray-300 text-right">{settings.temperature}</span>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Controls randomness: Lower is more deterministic, higher is more creative
                  </p>
                </div>
                
                {/* Top P */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Top P</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="0" 
                      max="1" 
                      step="0.05"
                      value={settings.topP}
                      onChange={(e) => handleSettingChange('topP', parseFloat(e.target.value))}
                      className="flex-grow"
                    />
                    <span className="w-8 text-sm text-gray-700 dark:text-gray-300 text-right">{settings.topP}</span>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Controls diversity via nucleus sampling
                  </p>
                </div>
                
                {/* Max Tokens Per Chunk */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Max Tokens Per Chunk</label>
                  <input 
                    type="number" 
                    value={settings.maxTokensPerChunk}
                    onChange={(e) => handleSettingChange('maxTokensPerChunk', parseInt(e.target.value) || 4000)}
                    className="w-full p-2 text-sm border rounded dark:bg-gray-600 dark:border-gray-500 dark:text-white"
                    min="1000"
                    max="16000"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Smaller values process faster but may miss context
                  </p>
                </div>
                
                {/* Max Output Tokens */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Max Output Tokens</label>
                  <input 
                    type="number" 
                    value={settings.maxOutputTokens}
                    onChange={(e) => handleSettingChange('maxOutputTokens', parseInt(e.target.value) || 2000)}
                    className="w-full p-2 text-sm border rounded dark:bg-gray-600 dark:border-gray-500 dark:text-white"
                    min="500"
                    max="4000"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Maximum length of model's response
                  </p>
                </div>
                
                {/* Frequency Penalty */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Frequency Penalty</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="-2" 
                      max="2" 
                      step="0.1"
                      value={settings.frequencyPenalty}
                      onChange={(e) => handleSettingChange('frequencyPenalty', parseFloat(e.target.value))}
                      className="flex-grow"
                    />
                    <span className="w-8 text-sm text-gray-700 dark:text-gray-300 text-right">{settings.frequencyPenalty}</span>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Reduces repetition of token sequences
                  </p>
                </div>
                
                {/* Presence Penalty */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Presence Penalty</label>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="-2" 
                      max="2" 
                      step="0.1"
                      value={settings.presencePenalty}
                      onChange={(e) => handleSettingChange('presencePenalty', parseFloat(e.target.value))}
                      className="flex-grow"
                    />
                    <span className="w-8 text-sm text-gray-700 dark:text-gray-300 text-right">{settings.presencePenalty}</span>
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Increases likelihood of discussing new topics
                  </p>
                </div>
                
                {/* Timeout */}
                <div>
                  <label className="block mb-1 text-sm font-medium text-gray-600 dark:text-gray-400">Request Timeout (seconds)</label>
                  <input 
                    type="number" 
                    value={settings.timeout}
                    onChange={(e) => handleSettingChange('timeout', parseInt(e.target.value) || 300)}
                    className="w-full p-2 text-sm border rounded dark:bg-gray-600 dark:border-gray-500 dark:text-white"
                    min="60"
                    max="3600"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Maximum time to wait for analysis
                  </p>
                </div>
              </div>
            </div>
            
            {/* Prompt templates */}
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-3 dark:text-gray-200">Prompt Templates</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-3 bg-white dark:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-500">
                  <h4 className="font-medium text-sm mb-2 dark:text-gray-200">Error Analysis</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    Template optimized for analyzing error logs and stack traces.
                  </p>
                  <div className="mt-2 flex justify-end">
                    <button className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300">
                      Use
                    </button>
                  </div>
                </div>
                
                <div className="p-3 bg-white dark:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-500">
                  <h4 className="font-medium text-sm mb-2 dark:text-gray-200">Performance Optimization</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    Template for identifying performance bottlenecks and suggesting optimizations.
                  </p>
                  <div className="mt-2 flex justify-end">
                    <button className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300">
                      Use
                    </button>
                  </div>
                </div>
                
                <div className="p-3 bg-white dark:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-500">
                  <h4 className="font-medium text-sm mb-2 dark:text-gray-200">Crash Analysis</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    Detailed analysis of crash reports and exception handling.
                  </p>
                  <div className="mt-2 flex justify-end">
                    <button className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300">
                      Use
                    </button>
                  </div>
                </div>
                
                <div className="p-3 bg-white dark:bg-gray-600 rounded-lg border border-gray-200 dark:border-gray-500">
                  <h4 className="font-medium text-sm mb-2 dark:text-gray-200">Security Audit</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-300">
                    Prompt template for identifying potential security vulnerabilities.
                  </p>
                  <div className="mt-2 flex justify-end">
                    <button className="text-xs px-2 py-1 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 dark:bg-blue-900 dark:text-blue-300">
                      Use
                    </button>
                  </div>
                </div>
              </div>
              
              <div className="mt-3 text-right">
                <button className="text-sm text-blue-600 hover:text-blue-800 dark:text-blue-400 hover:underline">
                  Create custom template...
                </button>
              </div>
            </div>
            
            {/* Recommended Use Cases */}
            <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
              <h3 className="text-lg font-medium mb-3 dark:text-gray-200">Recommended Use Cases</h3>
              
              <div className="space-y-2">
                {model.specialization === 'Code analysis' && (
                  <>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Stack trace and exception analysis
                    </div>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Code-related error debugging
                    </div>
                  </>
                )}
                
                {(model.specialization === 'Fast analysis' || model.specialization === 'General purpose') && (
                  <>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Quick initial assessment of issues
                    </div>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Standard log file analysis
                    </div>
                  </>
                )}
                
                {model.specialization === 'Technical depth' && (
                  <>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Complex technical issue analysis
                    </div>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Detailed root cause investigation
                    </div>
                  </>
                )}
                
                {model.specialization === 'Deep analysis' && (
                  <>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Comprehensive system-wide analysis
                    </div>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Multi-factor issue investigation
                    </div>
                  </>
                )}
                
                {model.specialization === 'Premium insights' && (
                  <>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      High-quality explanations for non-technical stakeholders
                    </div>
                    <div className="p-2 bg-white dark:bg-gray-600 rounded text-sm text-gray-800 dark:text-gray-200">
                      Mission-critical issue analysis
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
        
        {/* Footer with action buttons */}
        <div className="mt-6 flex justify-end space-x-3">
          <button
            onClick={handleClose}
            className="px-4 py-2 border border-gray-300 dark:border-gray-600 text-gray-700 dark:text-gray-200 rounded hover:bg-gray-50 dark:hover:bg-gray-700"
          >
            Close
          </button>
          
          {model.loaded && !isSelected && (
            <button
              onClick={() => {
                onSelectModel(model.id);
                onClose();
              }}
              className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600"
            >
              Select This Model
            </button>
          )}
          
          {isSelected && (
            <button
              onClick={handleClose}
              className="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600"
            >
              Update Settings
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default ModelDetailsModal;