// src/components/LLMSelector.js
import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import ModelDetailsModal from './Modals/ModelDetailsModal';

const API_URL = 'http://localhost:8000'; // Update with your actual API URL

/**
 * LLM Selector Component - Displays available models with status indicators
 * and allows selection for analysis
 * 
 * @param {Object} props
 * @param {string} props.selectedModel - Currently selected model
 * @param {function} props.onModelSelect - Function to call when model is selected
 * @param {boolean} props.disabled - Whether the selector is disabled
 * @param {function} props.onUpdateModelSettings - Function to update model settings
 */
const LLMSelector = ({ selectedModel, onModelSelect, disabled = false, onUpdateModelSettings }) => {
  const [models, setModels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModelDetails, setShowModelDetails] = useState(false);
  const [selectedModelDetails, setSelectedModelDetails] = useState(null);
  const [isCollapsed, setIsCollapsed] = useState(false);
  
  // Fetch models from API
  const fetchModels = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      
      // Initialize empty array for all models
      let allModels = [];
      
      // Try to fetch Ollama models directly from the Ollama API
      try {
        const ollamaResponse = await axios.get('http://localhost:11434/api/tags');
        if (ollamaResponse.data && ollamaResponse.data.models) {
          const ollamaModels = ollamaResponse.data.models.map(model => ({
            id: model.name, // Use name as ID for proper selection
            name: model.name.replace(/^([a-z]+)(:[\w-]+)?/, (match, name) => 
              name.charAt(0).toUpperCase() + name.slice(1)), // Better display name
            loaded: true,
            status: 'healthy',
            health: 'healthy',
            size: model.size ? `${Math.round(model.size / 1e9)}B` : 'Unknown',
            specialization: determineSpecialization(model.name),
            description: determineDescription(model.name),
            provider: 'ollama',
            avgResponseTime: 1.5, // Default values
            throughput: 30.0,
            // Default settings for Ollama models
            settings: {
              temperature: 0.7,
              topP: 0.9,
              maxTokensPerChunk: 4000,
              maxOutputTokens: 2000,
              frequencyPenalty: 0,
              presencePenalty: 0,
              timeout: 300
            }
          }));
          allModels = [...allModels, ...ollamaModels];
          console.log('Loaded Ollama models:', ollamaModels);
        }
      } catch (ollamaError) {
        console.warn('Failed to fetch Ollama models directly:', ollamaError);
        
        // Fallback: try to load models from the app's API as before
        // ...
      }
      
      // Add OpenAI models
      const openAIModels = [
        {
          id: 'gpt-4',
          name: 'GPT-4 Turbo',
          loaded: true,
          status: 'healthy',
          health: 'healthy',
          size: '1.8T',
          specialization: 'Premium insights',
          description: 'Premium OpenAI model with highest accuracy and best explanations',
          provider: 'openai',
          avgResponseTime: 2.8,
          throughput: 45.2,
          lastError: null,
          // Default settings for OpenAI models
          settings: {
            temperature: 0.7,
            topP: 0.9,
            maxTokensPerChunk: 8000,
            maxOutputTokens: 2048,
            frequencyPenalty: 0,
            presencePenalty: 0,
            timeout: 300
          }
        },
        {
          id: 'gpt-3.5-turbo',
          name: 'GPT-3.5 Turbo',
          loaded: true,
          status: 'healthy',
          health: 'healthy',
          size: '175B',
          specialization: 'Fast analysis',
          description: 'Fast and efficient OpenAI model, good for general analysis',
          provider: 'openai',
          avgResponseTime: 1.1,
          throughput: 65.5,
          lastError: null,
          settings: {
            temperature: 0.7,
            topP: 0.9,
            maxTokensPerChunk: 4000,
            maxOutputTokens: 1024,
            frequencyPenalty: 0,
            presencePenalty: 0,
            timeout: 120
          }
        }
      ];
      
      // Add OpenAI models to the list
      allModels = [...allModels, ...openAIModels];
      
      // Remove duplicates (in case we loaded models from both Ollama and API)
      const uniqueModels = allModels.reduce((acc, current) => {
        const x = acc.find(item => item.id === current.id);
        if (!x) {
          return acc.concat([current]);
        } else {
          return acc;
        }
      }, []);
      
      // Try to load saved settings for each model
      try {
        const savedSettings = JSON.parse(localStorage.getItem('modelSettings') || '{}');
        
        // Update models with saved settings
        uniqueModels.forEach(model => {
          if (savedSettings[model.id]) {
            model.settings = {
              ...model.settings,
              ...savedSettings[model.id]
            };
          }
        });
      } catch (e) {
        console.warn('Failed to load saved model settings:', e);
      }
      
      setModels(uniqueModels);
      
      // Debug log to check loaded models
      console.log('Loaded models:', uniqueModels);
      console.log('Current selectedModel:', selectedModel);
      
      // Set default selected model if none is selected yet
      if (!selectedModel && uniqueModels.length > 0) {
        onModelSelect(uniqueModels[0].id);
      }
    } catch (err) {
      console.error('Error fetching models:', err);
      setError(err.message || 'Failed to load models');
      setModels([]);
    } finally {
      setLoading(false);
    }
  }, [selectedModel, onModelSelect]);
  
  // Helper functions for model metadata
  function determineSpecialization(name) {
    name = name.toLowerCase();
    if (name.includes('code') || name.includes('starcoder')) {
      return 'Code analysis';
    } else if (name.includes('mistral')) {
      return 'Fast analysis';
    } else if (name.includes('mixtral') || name.includes('moe')) {
      return 'Deep analysis';
    } else if ((name.includes('llama') || name.includes('llama2')) && 
              (name.includes('70b') || name.includes('13b'))) {
      return 'Technical depth';
    } else if (name.includes('gpt-4')) {
      return 'Premium insights';
    }
    return 'General purpose';
  }
  
  function determineDescription(name) {
    const specialization = determineSpecialization(name);
    
    if (specialization === 'Code analysis') {
      return 'Specialized for code and stack trace analysis';
    } else if (specialization === 'Fast analysis') {
      return 'Balanced speed and accuracy for quick analysis';
    } else if (specialization === 'Deep analysis') {
      return 'Comprehensive analysis with deeper insights';
    } else if (specialization === 'Technical depth') {
      return 'Detailed technical analysis for complex issues';
    } else if (specialization === 'Premium insights') {
      return 'Highest quality analysis with detailed explanations';
    }
    return 'General purpose model for log analysis';
  }
  
  // Effect to fetch models on mount and refresh periodically
  useEffect(() => {
    fetchModels();
    
    // Refresh model status periodically
    const intervalId = setInterval(fetchModels, 60000); // Every minute
    
    return () => clearInterval(intervalId);
  }, [fetchModels]);
  
  // Debug the current selected model
  useEffect(() => {
    console.log(`LLMSelector received selectedModel: ${selectedModel || 'none'}`);
    
    if (selectedModel && models.length > 0) {
      const foundModel = models.find(m => m.id === selectedModel);
      console.log('Found model for selected ID:', foundModel);
      
      // Check if the model is found but not showing as selected
      if (foundModel && selectedModel !== foundModel.id) {
        console.warn(`ID mismatch: ${selectedModel} vs ${foundModel.id}`);
      }
    }
  }, [selectedModel, models]);
  
  const getStatusColor = (status) => {
    switch(status) {
      case 'healthy': return 'bg-green-500';
      case 'degraded': return 'bg-yellow-500';
      case 'error': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };
  
  const handleModelSelect = (modelId) => {
    if (disabled) return;
    
    console.log(`Attempting to select model: ${modelId}`);
    
    const model = models.find(m => m.id === modelId);
    console.log('Found model:', model);
    
    if (model && model.loaded) {
      console.log(`Selecting model: ${modelId}`);
      onModelSelect(modelId);
    } else {
      console.log(`Model ${modelId} is not available or not loaded`);
    }
  };
  
  const showDetails = (model) => {
    setSelectedModelDetails(model);
    setShowModelDetails(true);
  };

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };
  
  // Handle model settings update
  const handleUpdateModelSettings = (modelId, newSettings) => {
    // Update the models array with new settings
    const updatedModels = models.map(model => {
      if (model.id === modelId) {
        return {
          ...model,
          settings: {
            ...model.settings,
            ...newSettings
          }
        };
      }
      return model;
    });
    
    setModels(updatedModels);
    
    // Save settings to localStorage
    try {
      const currentSettings = JSON.parse(localStorage.getItem('modelSettings') || '{}');
      const updatedSettings = {
        ...currentSettings,
        [modelId]: newSettings
      };
      localStorage.setItem('modelSettings', JSON.stringify(updatedSettings));
    } catch (e) {
      console.error('Failed to save model settings:', e);
    }
    
    // Call the parent handler if provided
    if (onUpdateModelSettings) {
      onUpdateModelSettings(modelId, newSettings);
    }
  };
  
  // Prepare the render content based on loading/error states
  let content;
  
  if (loading) {
    content = (
      <div className="flex justify-center items-center p-4 h-24">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
        <span className="ml-2 text-gray-600 dark:text-gray-400">Loading models...</span>
      </div>
    );
  } else if (error) {
    content = (
      <div className="bg-red-50 dark:bg-red-900/20 border-l-4 border-red-500 p-4 mb-4 rounded">
        <div className="flex">
          <div className="flex-shrink-0">
            <svg className="h-5 w-5 text-red-500" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
            </svg>
          </div>
          <div className="ml-3">
            <p className="text-sm text-red-700 dark:text-red-300">
              Failed to load models: {error}
            </p>
            <button 
              className="mt-2 text-sm text-red-600 hover:text-red-800 dark:text-red-400 hover:underline"
              onClick={fetchModels}
            >
              Try again
            </button>
          </div>
        </div>
      </div>
    );
  } else {
    content = (
      <>
        {/* Selected model summary (always visible) */}
        {selectedModel && models.length > 0 && (
          <div className="border rounded-lg p-3 bg-gray-50 dark:bg-gray-700 dark:border-gray-600 mb-3">
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                {/* Find the model that matches the selected ID */}
                {(() => {
                  const model = models.find(m => m.id === selectedModel);
                  return model ? (
                    <>
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(model.status)} mr-2`}></div>
                      <h3 className="font-medium text-gray-900 dark:text-gray-100">
                        {model.name}
                      </h3>
                      {model.provider && (
                        <span className="ml-2 px-2 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 text-xs rounded-full">
                          {model.provider === 'openai' ? 'OpenAI' : model.provider}
                        </span>
                      )}
                    </>
                  ) : (
                    <h3 className="font-medium text-gray-900 dark:text-gray-100">
                      No model selected
                    </h3>
                  );
                })()}
              </div>
              <div className="flex items-center space-x-2">
                <span className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                  {(() => {
                    const model = models.find(m => m.id === selectedModel);
                    return model ? model.specialization : 'Unknown';
                  })()}
                </span>
                {/* Configure settings button */}
                <button
                  onClick={() => {
                    const model = models.find(m => m.id === selectedModel);
                    if (model) {
                      setSelectedModelDetails(model);
                      setShowModelDetails(true);
                    }
                  }}
                  className="text-xs px-2 py-1 rounded bg-gray-100 text-gray-700 hover:bg-gray-200 dark:bg-gray-600 dark:text-gray-300 dark:hover:bg-gray-500"
                >
                  Configure
                </button>
              </div>
            </div>
          </div>
        )}
        
        {/* Collapsible grid of models */}
        <div className={`overflow-hidden transition-all duration-300 ease-in-out ${isCollapsed ? 'max-h-0 opacity-0' : 'max-h-[2000px] opacity-100'}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 mb-4">
            {models.map(model => {
              const isSelected = selectedModel === model.id;
              return (
                <div 
                  key={model.id} 
                  className={`border rounded-lg p-3 flex flex-col transition-all cursor-pointer transform hover:scale-[1.02] ${
                    isSelected 
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/20' 
                      : 'border-gray-200 dark:border-gray-700'
                  } ${!model.loaded || disabled ? 'opacity-60' : ''}`}
                  onClick={() => model.loaded && !disabled && handleModelSelect(model.id)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center">
                      <div className={`w-3 h-3 rounded-full ${getStatusColor(model.status)} mr-2`}></div>
                      <h3 className="font-medium text-gray-900 dark:text-gray-100">{model.name}</h3>
                      {!model.loaded && (
                        <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300 text-xs rounded-full">
                          Offline
                        </span>
                      )}
                      
                      {/* Provider badge */}
                      {model.provider && (
                        <span className="ml-2 px-2 py-0.5 bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300 text-xs rounded-full">
                          {model.provider === 'openai' ? 'OpenAI' : model.provider}
                        </span>
                      )}
                    </div>
                  </div>
                  
                  {/* Specialization badge */}
                  <div className="flex items-center mb-2">
                    <span className={`text-xs px-2 py-1 rounded-full ${
                      model.specialization === 'General purpose' ? 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300' :
                      model.specialization === 'Technical depth' ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300' :
                      model.specialization === 'Deep analysis' ? 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300' :
                      model.specialization === 'Premium insights' ? 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300' :
                      model.specialization === 'Fast analysis' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' :
                      model.specialization === 'Code analysis' ? 'bg-amber-100 text-amber-800 dark:bg-amber-900 dark:text-amber-300' :
                      'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300'
                    }`}>
                      {model.specialization}
                    </span>
                  </div>
                  
                  <div className="text-xs text-gray-600 dark:text-gray-400 mb-2 line-clamp-2 h-8">
                    {model.description}
                  </div>
                  
                  <div className="mt-auto flex justify-between items-center pt-2 border-t border-gray-100 dark:border-gray-700">
                    <div className="text-xs text-gray-500 dark:text-gray-400">
                      {model.size}
                    </div>
                    
                    <div className="flex space-x-2">
                      {model.loaded && !disabled && (
                        <button 
                          className="text-xs text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-300"
                          onClick={(e) => {
                            e.stopPropagation();
                            showDetails(model);
                          }}
                        >
                          Details
                        </button>
                      )}
                      {isSelected && (
                        <span className="text-xs text-green-600 dark:text-green-400 font-medium">
                          Selected
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </>
    );
  }
  
  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm p-4 mb-4">
      <div className="flex justify-between items-center mb-2">
        <h2 className="text-lg font-semibold text-gray-800 dark:text-gray-200">Select LLM for Analysis</h2>
        <button 
          onClick={toggleCollapse}
          className="text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 focus:outline-none"
          aria-expanded={!isCollapsed}
          aria-label={isCollapsed ? "Expand model selector" : "Collapse model selector"}
        >
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className={`h-5 w-5 transition-transform duration-200 ${isCollapsed ? 'rotate-180' : ''}`} 
            viewBox="0 0 20 20" 
            fill="currentColor"
          >
            <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
        </button>
      </div>
      
      {content}
      
      {/* Model details modal */}
      {showModelDetails && selectedModelDetails && (
        <ModelDetailsModal
          model={selectedModelDetails}
          isOpen={showModelDetails}
          onClose={() => setShowModelDetails(false)}
          onSelectModel={handleModelSelect}
          isSelected={selectedModel === selectedModelDetails.id}
          onUpdateSettings={handleUpdateModelSettings}
        />
      )}
    </div>
  );
};

export default LLMSelector;