// src/components/LanguageSelector.js
import React, { useMemo, useState, useEffect } from 'react';
import Select, { components } from 'react-select';
import CountryFlag from 'react-country-flag';
import PropTypes from 'prop-types';

const DEFAULT_LANGUAGES = [
  { value: 'en', label: 'English', countryCode: 'GB' },
  { value: 'nl', label: 'Dutch', countryCode: 'NL' },
  { value: 'mk', label: 'Macedonian', countryCode: 'MK' },
  { value: 'fr', label: 'French', countryCode: 'FR' },
  { value: 'es', label: 'Spanish', countryCode: 'ES' },
  { value: 'pl', label: 'Polish', countryCode: 'PL' },
];

const Option = (props) => (
  <components.Option {...props}>
    {props.data.countryCode && (
      <CountryFlag 
        countryCode={props.data.countryCode} 
        svg 
        style={{ marginRight: '8px' }} 
        aria-hidden="true"
        alt=""
      />
    )}
    {props.data.label}
  </components.Option>
);

const SingleValue = (props) => (
  <components.SingleValue {...props}>
    {props.data.countryCode && (
      <CountryFlag 
        countryCode={props.data.countryCode} 
        svg 
        style={{ marginRight: '8px' }} 
        aria-hidden="true"
        alt=""
      />
    )}
    {props.data.label}
  </components.SingleValue>
);

const LanguageSelector = ({ 
  selectedLanguage, 
  onChange, 
  languages = DEFAULT_LANGUAGES, 
  isDisabled = false,
  defaultLanguage = 'en',
  className = '',
  'aria-label': ariaLabel = 'Select language',
}) => {

  const selectedOption = useMemo(() => {
    return languages.find(lang => lang.value === selectedLanguage)
      || languages.find(lang => lang.value === defaultLanguage)
      || languages[0];
  }, [selectedLanguage, languages, defaultLanguage]);

  return (
    <div className={`language-selector ${className}`}>
      <Select
        options={languages}
        components={{ Option, SingleValue }}
        value={selectedOption}
        onChange={onChange}
        isDisabled={isDisabled}
        aria-label={ariaLabel}
        isSearchable={false}
        menuPlacement="auto"
        classNamePrefix="language-select"
      />
    </div>
  );
};

LanguageSelector.propTypes = {
  selectedLanguage: PropTypes.string.isRequired,
  onChange: PropTypes.func.isRequired,
  languages: PropTypes.arrayOf(
    PropTypes.shape({
      value: PropTypes.string.isRequired,
      label: PropTypes.string.isRequired,
      countryCode: PropTypes.string
    })
  ),
  isDisabled: PropTypes.bool,
  defaultLanguage: PropTypes.string,
  className: PropTypes.string,
  'aria-label': PropTypes.string,
};

export default LanguageSelector;
