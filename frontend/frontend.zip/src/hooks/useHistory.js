import { useState, useEffect, useCallback } from 'react';

const useHistory = () => {
  const [analysisHistory, setAnalysisHistory] = useState([]);

  // Load history on mount
  useEffect(() => {
    try {
      const savedHistory = localStorage.getItem('analysisHistory');
      if (savedHistory) {
        setAnalysisHistory(JSON.parse(savedHistory));
      }
    } catch (err) {
      console.error('Failed to load history:', err);
    }
  }, []);

  // Save analysis to history
  const saveToHistory = useCallback((analysis, filename = 'Analysis Result', analysisType = 'original') => {
    try {
      const timestamp = new Date().toISOString();
      
      // Save full analysis
      localStorage.setItem(`analysis_${timestamp}`, JSON.stringify(analysis));
      
      // Update history list
      const updatedHistory = [
        {
          timestamp,
          filename,
          analysisType,
        },
        ...analysisHistory
      ].slice(0, 10); // Keep only the 10 most recent entries
      
      localStorage.setItem('analysisHistory', JSON.stringify(updatedHistory));
      setAnalysisHistory(updatedHistory);
      
      return timestamp;
    } catch (err) {
      console.error('Failed to save to history:', err);
      return null;
    }
  }, [analysisHistory]);

  // Load analysis from history
  const loadFromHistory = useCallback((historyItem) => {
    try {
      const savedAnalysis = localStorage.getItem(`analysis_${historyItem.timestamp}`);
      if (savedAnalysis) {
        return JSON.parse(savedAnalysis);
      }
      return null;
    } catch (err) {
      console.error('Failed to load from history:', err);
      return null;
    }
  }, []);

  // Clear all history
  const clearHistory = useCallback(() => {
    try {
      // Get all history items first
      const historyItems = [...analysisHistory];
      
      // Remove all saved analyses
      historyItems.forEach(item => {
        localStorage.removeItem(`analysis_${item.timestamp}`);
      });
      
      // Remove history list
      localStorage.removeItem('analysisHistory');
      setAnalysisHistory([]);
      
      return true;
    } catch (err) {
      console.error('Failed to clear history:', err);
      return false;
    }
  }, [analysisHistory]);

  return {
    analysisHistory,
    saveToHistory,
    loadFromHistory,
    clearHistory
  };
};

export default useHistory;