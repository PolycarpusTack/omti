import { useState, useCallback, useEffect } from 'react';
import axios from 'axios';
import { API_URL, REQUEST_TIMEOUT } from '../constants';

const useAnalysis = () => {
  const [analyses, setAnalyses] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [progress, setProgress] = useState(0);
  const [progressStatus, setProgressStatus] = useState('Initializing...');
  const [categorizedIssues, setCategorizedIssues] = useState({
    critical: [],
    high: [],
    medium: [],
    low: []
  });

  // Function to categorize issues from analysis results
  const categorizeIssues = useCallback((analysisData) => {
    if (!analysisData || analysisData.length === 0) return;
    
    const categorized = {
      critical: [],
      high: [],
      medium: [],
      low: []
    };
    
    analysisData.forEach(analysis => {
      // Content to analyze
      const content = `${analysis.technical_analysis || ''} ${analysis.simplified_analysis || ''}`;
      
      // Process crash-focused analysis
      if (analysis.crash_resolution_report && analysis.diagnostic_overview_report) {
        const crashContent = `${analysis.crash_resolution_report} ${analysis.diagnostic_overview_report}`;
        
        if (/crash|exception|fatal|failure|deadlock/i.test(crashContent)) {
          categorized.critical.push({
            id: `crash-critical-${new Date().getTime()}`,
            description: extractIssueDescription(crashContent, 'critical'),
            source: analysis
          });
        }
        return;
      }
      
      // Process original analysis mode
      if (/crash|exception|fatal|failure|deadlock/i.test(content)) {
        categorized.critical.push({
          id: `${analysis.chunk}-critical`,
          description: extractIssueDescription(content, 'critical'),
          source: analysis
        });
      }
      
      if (/error|warning|leak|overflow/i.test(content) && !/crash|exception|fatal/i.test(content)) {
        categorized.high.push({
          id: `${analysis.chunk}-high`,
          description: extractIssueDescription(content, 'high'),
          source: analysis
        });
      }
      
      if (/warning|potential issue|consider|might/i.test(content) && !/error|crash|exception/i.test(content)) {
        categorized.medium.push({
          id: `${analysis.chunk}-medium`,
          description: extractIssueDescription(content, 'medium'),
          source: analysis
        });
      }
      
      if (/info|note|reminder|suggestion/i.test(content) && !/warning|error|crash|exception/i.test(content)) {
        categorized.low.push({
          id: `${analysis.chunk}-low`,
          description: extractIssueDescription(content, 'low'),
          source: analysis
        });
      }
    });
    
    setCategorizedIssues(categorized);
  }, []);

  function extractIssueDescription(content, severity) {
    const patterns = {
      critical: /(.*?(?:crash|exception|fatal|failure|deadlock).*?\.)/i,
      high: /(.*?(?:error|warning|leak|overflow).*?\.)/i,
      medium: /(.*?(?:warning|potential issue|consider|might).*?\.)/i,
      low: /(.*?(?:info|note|reminder|suggestion).*?\.)/i
    };
    
    const match = content.match(patterns[severity]);
    return match ? match[1] : 'Issue detected';
  }

  // Perform analysis when analyses state changes
  useEffect(() => {
    if (analyses.length > 0) {
      categorizeIssues(analyses);
      
      // Save to localStorage for history
      try {
        const timestamp = new Date().toISOString();
        localStorage.setItem(`analysis_${timestamp}`, JSON.stringify(analyses));
        
        // Update history
        const savedHistory = JSON.parse(localStorage.getItem('analysisHistory') || '[]');
        const newHistory = [
          {
            timestamp,
            filename: 'Analysis Result',
            analysisType: analyses[0].crash_resolution_report ? 'crash' : 'original'
          },
          ...savedHistory
        ].slice(0, 10); // Keep only the 10 most recent
        
        localStorage.setItem('analysisHistory', JSON.stringify(newHistory));
      } catch (err) {
        console.error('Failed to save to history:', err);
      }
    }
  }, [analyses, categorizeIssues]);

  // Upload and analyze file
  const analyzeFile = useCallback(async (file, settings) => {
    if (!file) {
      setError('No file selected');
      return;
    }
    
    const { language, model, maxTokensPerChunk, timeout, analysisType, streamMode } = settings;
    
    setLoading(true);
    setError('');
    setProgress(0);
    setProgressStatus('Initializing analysis...');
    setAnalyses([]);
    
    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('language', language);
      // Ensure a valid model is always sent - this fixes the "undefined" model issue
      formData.append('model', model || 'mistral');
      formData.append('max_tokens_per_chunk', maxTokensPerChunk);
      formData.append('timeout', timeout);
      
      setProgressStatus('Preparing file for analysis...');
      setProgress(5);
      
      let response;
      
      if (analysisType === 'crash') {
        // Use crash-focused endpoint
        setProgressStatus('Analyzing crash data...');
        setProgress(10);
        
        response = await axios.post(`${API_URL}full`, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: timeout * 1000 || REQUEST_TIMEOUT
        });
        
        if (response.data) {
          setProgressStatus('Processing crash analysis results...');
          setProgress(90);
          
          setAnalyses([{
            crash_resolution_report: response.data.crash_resolution_report,
            diagnostic_overview_report: response.data.diagnostic_overview_report,
            timestamp: response.data.timestamp || new Date().toISOString()
          }]);
        }
      } else if (streamMode) {
        // Streaming mode using fetch API for real-time updates
        setProgressStatus('Starting streaming analysis...');
        setProgress(10);
        
        const fetchResponse = await fetch(API_URL, {
          method: 'POST',
          body: formData
        });
        
        if (!fetchResponse.ok) {
          throw new Error(`HTTP error! Status: ${fetchResponse.status}`);
        }
        
        const reader = fetchResponse.body.getReader();
        const decoder = new TextDecoder('utf-8');
        let buffer = '';
        
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split('\n');
          buffer = lines.pop() || '';
          
          for (const line of lines) {
            if (line.trim()) {
              try {
                const parsed = JSON.parse(line.trim());
                setAnalyses(prev => [...prev, parsed]);
                
                const progressValue = Math.round((parsed.chunk / parsed.total_chunks) * 90) + 10;
                setProgress(Math.min(progressValue, 99));
                setProgressStatus(`Analyzing chunk ${parsed.chunk} of ${parsed.total_chunks}...`);
              } catch (parseErr) {
                console.error('Error parsing streamed JSON:', parseErr);
              }
            }
          }
        }
        
        // Process any remaining data
        if (buffer.trim()) {
          try {
            const parsed = JSON.parse(buffer.trim());
            setAnalyses(prev => [...prev, parsed]);
          } catch (parseErr) {
            console.error('Error parsing final JSON chunk:', parseErr);
          }
        }
      } else {
        // Traditional non-streaming mode
        setProgressStatus('Processing file...');
        setProgress(30);
        
        response = await axios.post(API_URL, formData, {
          headers: { 'Content-Type': 'multipart/form-data' },
          timeout: timeout * 1000 || REQUEST_TIMEOUT
        });
        
        setProgressStatus('Analyzing content...');
        setProgress(70);
        
        if (response.data.full_analysis) {
          setAnalyses([{
            chunk: 1,
            total_chunks: 1,
            technical_analysis: response.data.full_analysis,
            simplified_analysis: response.data.full_analysis,
            suggested_solutions: 'Available in streaming mode only',
            timestamp: new Date().toISOString()
          }]);
        } else if (response.data.analysis) {
          setAnalyses([{
            chunk: 1,
            total_chunks: 1,
            technical_analysis: response.data.analysis,
            simplified_analysis: response.data.analysis,
            suggested_solutions: response.data.analysis,
            timestamp: new Date().toISOString()
          }]);
        }
      }
      
      setProgressStatus('Completing analysis...');
      setProgress(100);
    } catch (err) {
      console.error('Upload error:', err);
      setError(err.message || 'An error occurred during file analysis');
      setProgressStatus('Analysis failed');
    } finally {
      setLoading(false);
    }
  }, []);

  // Load analysis from history or shared URL
  const loadAnalysis = useCallback((historyItem) => {
    try {
      const savedAnalysis = localStorage.getItem(`analysis_${historyItem.timestamp}`);
      if (savedAnalysis) {
        setAnalyses(JSON.parse(savedAnalysis));
        return true;
      } else {
        setError('Could not find the saved analysis');
        return false;
      }
    } catch (err) {
      console.error('Failed to load analysis from history:', err);
      setError('Failed to load analysis from history');
      return false;
    }
  }, []);

  // Load from shared URL
  const loadFromSharedUrl = useCallback((sharedParam) => {
    try {
      if (!sharedParam) return false;
      
      const decompressedData = JSON.parse(atob(sharedParam));
      // Convert the minimal data back to a format compatible with your app
      const reconstructedAnalyses = decompressedData.map(d => ({
        chunk: d.c,
        total_chunks: d.tc,
        simplified_analysis: d.s,
        technical_analysis: d.t || 'Not available in shared view',
        suggested_solutions: d.sol || 'Not available in shared view',
        timestamp: new Date().toISOString()
      }));
      
      setAnalyses(reconstructedAnalyses);
      return true;
    } catch (e) {
      console.error('Error parsing shared URL:', e);
      setError('Failed to load shared analysis');
      return false;
    }
  }, []);

  // Generate a shareable URL
  const generateShareUrl = useCallback(() => {
    try {
      // Create a compressed version of the analysis for URL sharing
      const minimalData = analyses.map(a => ({
        c: a.chunk,
        tc: a.total_chunks,
        s: a.simplified_analysis?.substring(0, 200) + '...',
        t: a.technical_analysis?.substring(0, 100) + '...',
        sol: a.suggested_solutions?.substring(0, 100) + '...'
      }));
      const compressedData = btoa(JSON.stringify(minimalData));
      return `${window.location.origin}${window.location.pathname}?shared=${compressedData}`;
    } catch (e) {
      console.error('Error generating share URL:', e);
      setError('Could not generate share URL');
      return null;
    }
  }, [analyses]);

  // Format analysis for download
  const formatAnalysisForDownload = useCallback((format = 'txt') => {
    if (!analyses || analyses.length === 0) {
      setError('No analyses available to download');
      return null;
    }

    if (format === 'json') {
      // Create JSON format
      const jsonData = analyses.map(analysis => {
        if (analysis.crash_resolution_report && analysis.diagnostic_overview_report) {
          return {
            type: 'crash_analysis',
            timestamp: analysis.timestamp,
            crash_resolution_report: analysis.crash_resolution_report,
            diagnostic_overview_report: analysis.diagnostic_overview_report
          };
        }
        
        return {
          type: 'chunk_analysis',
          chunk: analysis.chunk,
          total_chunks: analysis.total_chunks,
          timestamp: analysis.timestamp,
          simplified_analysis: analysis.simplified_analysis,
          technical_analysis: analysis.technical_analysis,
          suggested_solutions: analysis.suggested_solutions
        };
      });
      
      return {
        data: JSON.stringify(jsonData, null, 2),
        type: 'application/json',
        extension: 'json'
      };
    } else {
      // Default to text format
      const formattedText = analyses.map(analysis => {
        // For crash-focused analysis mode
        if (analysis.crash_resolution_report && analysis.diagnostic_overview_report) {
          return `
=== CRASH RESOLUTION REPORT ===
Generated at: ${analysis.timestamp ? new Date(analysis.timestamp).toLocaleString() : 'N/A'}

${analysis.crash_resolution_report}

=== DIAGNOSTIC OVERVIEW REPORT ===
Generated at: ${analysis.timestamp ? new Date(analysis.timestamp).toLocaleString() : 'N/A'}

${analysis.diagnostic_overview_report}
          `;
        }
        
        // For original analysis mode
        const { chunk, total_chunks, simplified_analysis, technical_analysis, suggested_solutions, timestamp } = analysis;
        return `
=== ANALYSIS CHUNK ${chunk}/${total_chunks} ===
Generated at: ${timestamp ? new Date(timestamp).toLocaleString() : 'N/A'}

--- EXPLANATION ---
${simplified_analysis || "Analysis not available"}

--- SUGGESTED SOLUTIONS ---
${suggested_solutions || "No solutions available"}

--- TECHNICAL DETAILS ---
${technical_analysis || "Technical analysis not available"}
        `;
      }).join('\n\n');
      
      return {
        data: formattedText,
        type: 'text/plain',
        extension: 'txt'
      };
    }
  }, [analyses]);

  // Highlight errors in text
  const highlightErrors = useCallback((text) => {
    if (!text) return '';
    
    // Replace error patterns with highlighted spans
    const withHighlights = text
      .replace(/ERROR|Exception|failed|failure/gi, match => 
        `<span class="text-red-500 font-semibold">${match}</span>`)
      .replace(/WARNING|WARN/gi, match => 
        `<span class="text-yellow-500 font-semibold">${match}</span>`)
      .replace(/INFO|INFORMATION/gi, match => 
        `<span class="text-blue-500 font-semibold">${match}</span>`);
    
    return { __html: withHighlights };
  }, []);

  return {
    // State
    analyses,
    loading,
    error,
    progress,
    progressStatus,
    categorizedIssues,
    
    // Actions
    setError,
    analyzeFile,
    loadAnalysis,
    loadFromSharedUrl,
    generateShareUrl,
    formatAnalysisForDownload,
    highlightErrors
  };
};

export default useAnalysis;